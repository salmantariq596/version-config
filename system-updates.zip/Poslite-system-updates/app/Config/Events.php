<?php

namespace Config;

use CodeIgniter\Events\Events;
use CodeIgniter\Exceptions\FrameworkException;
use CodeIgniter\HotReloader\HotReloader;
use App\Hooks\MenuHooks;
use App\Hooks\DatatableConfigHook;



//register data table menu segment
Events::on('post_system', [DatatableConfigHook::class, 'register']);

Events::on('pre_system', static function (): void {
    if (ENVIRONMENT !== 'testing') {
        if (ini_get('zlib.output_compression')) {
            throw FrameworkException::forEnabledZlibOutputCompression();
        }

        while (ob_get_level() > 0) {
            ob_end_flush();
        }

        ob_start(static fn ($buffer) => $buffer);
    }

    // $routeManager = new \App\Libraries\Modules\ModuleRouteManager();
    // $routeManager->loadModuleRoutes();

    /*
     * --------------------------------------------------------------------
     * Debug Toolbar Listeners.
     * --------------------------------------------------------------------
     * If you delete, they will no longer be collected.
     */
    if (CI_DEBUG && ! is_cli()) {
        Events::on('DBQuery', 'CodeIgniter\Debug\Toolbar\Collectors\Database::collect');
        service('toolbar')->respond();
        // Hot Reload route - for framework use on the hot reloader.
        if (ENVIRONMENT === 'development') {
            service('routes')->get('__hot-reload', static function (): void {
                (new HotReloader())->run();
    });
}}});

Events::on('pre_system', function () {
    set_exception_handler(function ($exception) {
        $errorHandler = Services::errorHandler();
        $response = $errorHandler->handleException($exception);
        
        if (is_string($response)) {
            echo $response;
        } else {
            $response->send();
        }
        exit(1);
    });
});

/*
 * --------------------------------------------------------------------
 * Menu Registration Event
 * --------------------------------------------------------------------
 * This event ensures menus are registered after the database connection
 * is established but before the application starts processing the request.
 */
Events::on('post_controller_constructor', static function(): void {
    try {
        MenuHooks::registerMenus();
    } catch (\Exception $e) {
        log_message('error', 'Menu registration failed: ' . $e->getMessage());
    }
});

// Events::on('pre_system', function() {
//     $routeManager = new \App\Libraries\Modules\ModuleRouteManager();
//     $routeManager->loadModuleRoutes();
// });
// /*
//  * --------------------------------------------------------------------
//  * Module Menu Registration
//  * --------------------------------------------------------------------
//  * This event allows modules to register their menus after the core
//  * menus have been registered.
//  */
// Events::on('post_system', static function(): void {
//     // Trigger module menu registration
//     $moduleManager = service('modules');
//     if ($moduleManager) {
//         foreach ($moduleManager->getActiveModules() as $module) {
//             if (method_exists($module, 'registerMenus')) {
//                 try {
//                     $module->registerMenus();
//                 } catch (\Exception $e) {
//                     log_message('error', "Failed to register menus for module {$module->getName()}: " . $e->getMessage());
//                 }
//             }
//         }
//     }
// });