<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>POS - Add Sales</title>
    
</head>

<body>
<div class="container-fluid px-0">
    <div class="d-flex flex-column flex-lg-row align-items-start justify-content-between">
        <!-- Left Column -->
        <div class="w-100 w-lg-40">
            <nav class="navbar navbar-light bg-light">
                <div class="container-fluid d-flex justify-content-between align-items-center">
                    <div class="d-flex gap-3 align-items-center">
                        <h1 class="text-orange mb-0">
                            <i class="bi bi-postcard"></i>
                        </h1>
                        <h2 class="offcanvas-title text-primary" id="offcanvasExampleLabel">POS Lite</h2>
                    </div>
                    <div>
                        <a href="<?= site_url('/dashboard-new') ?>" class="btn btn-success">Dashboard</a>
                        <button class="btn btn-light">Add Users</button>
                    </div>
                </div>
            </nav>

            <div class="card my-3">
                <div class="card-body">
                    <div class="input-group mb-3">
                        <label class="input-group-text" for="customerSelect">Customer</label>
                        <select class="form-select" id="customerSelect" name="customer_id">
                            <?php foreach ($customers as $customer): ?>
                                <option value="<?= $customer['id']; ?>"><?= $customer['name']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="input-group mb-3">
                        <label class="input-group-text" for="warehouseSelect">Warehouse</label>
                        <select class="form-select" id="warehouseSelect" name="warehouse_id">
                            <?php foreach ($warehouses as $warehouse): ?>
                                <option value="<?= $warehouse['id']; ?>"><?= $warehouse['name']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-sm table-bordered align-middle">
                            <thead>
                                <tr>
                                    <th>Item</th>
                                    <th>Qty</th>
                                    <th>Price</th>
                                    <th>Subtotal</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="billItems"></tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer">
                    <h4 class="btn btn-primary w-100">Total: $<span id="totalAmount">0.00</span></h4>
                </div>
            </div>

            <div class="container my-3">
                <div class="row gx-2 gy-3">
                    <div class="col-12 col-md-6">
                        <div class="input-group">
                            <input type="number" class="form-control" placeholder="Enter discount">
                            <span class="input-group-text">%</span>
                        </div>
                    </div>
                    <div class="col-12 col-md-6">
                        <div class="input-group">
                            <input type="number" class="form-control" placeholder="Enter tax">
                            <span class="input-group-text">%</span>
                        </div>
                    </div>
                </div>

                <div class="row gx-2 mt-3">
                    <div class="col-6">
                        <button class="btn btn-danger w-100">
                            <i class="bi bi-power"></i> Reset
                        </button>
                    </div>
                    <div class="col-6">
                        <button class="btn btn-success w-100" id="printBillDetails" data-bs-toggle="modal" data-bs-target="#checkoutModal">
                            <i class="bi bi-cart3"></i> Pay Now
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right Column -->
        <div class="w-100 w-lg-60 ps-3">
            <nav class="navbar navbar-light bg-light mb-3">
                <div class="container-fluid">
                    <button class="btn btn-lg btn-primary w-100 w-md-49">List of Categories</button>
                    <button class="btn btn-lg btn-primary w-100 w-md-49">List of Brands</button>
                </div>
            </nav>

            <div class="search-bar-container mx-auto mb-3">
                <img src="https://via.placeholder.com/150" alt="Barcode" class="barcode-img img-fluid">
                <input type="text" class="form-control mt-3" placeholder="Product name / Barcode....." onkeyup="filterProducts()">
            </div>

            <div id="categories-list" class="container my-4">
                <!-- Categories will be displayed here -->
            </div>

            <div id="products-list" class="container d-flex flex-wrap gap-3">
                <?php foreach ($products as $product): ?>
                    <div class="card product-card" style="width: calc(50% - 0.5rem);">
                        <img src="<?= base_url('uploads/' . $product['img']) ?>" class="card-img-top rounded-4" style="height: 120px; object-fit: cover;">
                        <div class="card-body px-0 text-center">
                            <h5 class="card-title"><?= esc($product['name']) ?></h5>
                            <p class="badge bg-primary">$<?= number_format($product['price'], 2) ?></p>
                            <button class="btn btn-sm btn-primary w-100" onclick="addToBill(<?= htmlspecialchars(json_encode($product), ENT_QUOTES, 'UTF-8') ?>)">
                                Add to Bill
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>
 <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        // Fetch categories when the button is clicked
        $('#listCategoriesBtn').on('click', function() {
            $.ajax({
                url: '/productcontroller/fetchCategories', // Controller method URL
                type: 'GET',
                success: function(response) {
                    let categoriesList = $('#categories-list');
                    categoriesList.empty(); // Clear previous list
                    response.forEach(function(category) {
                        categoriesList.append(`<button class="btn btn-light category-btn" data-category-id="${category.id}">${category.name}</button>`);
                        $('.category-btn').on('click', function() {
                            // Remove the 'active' class from all buttons
                            $('.category-btn').removeClass('active');

                            // Add the 'active' class to the clicked button
                            $(this).addClass('active');
                        });
                    });
                }
            });
        });

        // Fetch products when a category is clicked
        $(document).on('click', '.category-btn', function() {
            let categoryId = $(this).data('category-id');
            $.ajax({
                url: '/productcontroller/fetchProductsByCategory/' + categoryId, // Controller method URL
                type: 'GET',
                success: function(response) {
                    let productsList = $('#products-list');
                    productsList.empty(); // Clear previous products
                    if (response.length > 0) {
                        response.forEach(function(product) {
                            productsList.append(`
                                <div class="card m-2 product-card">
                                  <img src="${product.image_url}" class="card-img-top rounded-4" style="height: 80px; object-fit: cover;">

                                    <div class="card-body">
                                        <h5 class="card-title" style="font-size: 14px; margin-bottom: 3px;">${product.name}</h5>
                                        <p class="card-text mb-0 badge text-bg-primary" style="font-size: 12px;">
                                            $<?= number_format($product['price'], 2) ?>
                                        </p>
                                        
                                    <p class="card-text mb-0" style="font-size: 14px;">
                                        <i class="bi bi-upc-scan" data-bs-toggle="tooltip" data-bs-placement="top" title="Product Barcode"></i> 
                                         <?= esc($product['product_barcode']) ?>
                                            </p>

                                       <button class="btn btn-sm btn-primary w-100" onclick="addToBill(<?= htmlspecialchars(json_encode($product), ENT_QUOTES, 'UTF-8') ?>)">
                                    Add to Bill
                                </button>
                                    </div>
                                </div>
                            `);
                        });
                    } else {
                        productsList.append('<p>No products found in this category.</p>');
                    }
                }
            });
        });
    </script>
    <style>
        /* Apply green color when the button is active */
        .category-btn.active {
            background-color: #4F46E5;
            color: white;
            border-color: #4F46E5;
            /* Optional: Add border color */
        }
    </style>
    <script>
        function filterProducts() {
            var input = document.querySelector('.search-bar-container input');
            var searchValue = input.value.toLowerCase();
            var productCards = document.querySelectorAll('.product-card');

            // Check if input matches exact barcode
            var barcodeMatch = Array.from(productCards).find(card =>
                card.dataset.barcode.toLowerCase() === searchValue
            );

            if (barcodeMatch) {
                // Extract all necessary product data from the card
                const cardBody = barcodeMatch.querySelector('.card-body');
                const productData = {
                    id: parseInt(barcodeMatch.dataset.id),
                    name: cardBody.querySelector('.card-title').textContent.trim(),
                    price: parseFloat(cardBody.querySelector('.badge').textContent.replace('$', '')),
                    product_barcode: barcodeMatch.dataset.barcode,
                    available_stock: parseInt(barcodeMatch.dataset.stock || '0'),
                    img: barcodeMatch.querySelector('.card-img-top').src
                };

                // Find if item already exists in bill
                const existingItem = bill.find(item => item.id === productData.id);
                const newQuantity = existingItem ? existingItem.quantity + 1 : 1;

                // Check stock before adding
                if (newQuantity > productData.available_stock) {
                    alert(`Insufficient stock for "${productData.name}". Available stock: ${productData.available_stock}`);
                    input.value = '';
                    return;
                }

                // Add to bill and clear input
                addToBill(productData);
                input.value = '';
                hideSuggestions();
                return;
            }

            // If no barcode match, show name-based suggestions
            let suggestions = Array.from(productCards)
                .filter(card => {
                    var productName = card.querySelector('.card-title').textContent.toLowerCase();
                    return productName.includes(searchValue);
                })
                .slice(0, 5); // Limit to 5 suggestions

            showSuggestions(suggestions, input);
        }

        // Create and show suggestions dropdown
        function showSuggestions(suggestions, inputElement) {
            // Remove existing suggestions
            hideSuggestions();

            if (!suggestions.length || !inputElement.value) return;

            // Create suggestions container
            const suggestionsDiv = document.createElement('div');
            suggestionsDiv.className = 'suggestions-container position-absolute bg-white w-100 shadow-sm border rounded-bottom';
            suggestionsDiv.style.zIndex = '1000';

            suggestions.forEach(card => {
                const cardBody = card.querySelector('.card-body');
                const suggestion = document.createElement('div');
                suggestion.className = 'suggestion-item p-2 border-bottom cursor-pointer hover:bg-gray-100 d-flex justify-content-between align-items-center';

                // Create product info with name and price
                const productInfo = document.createElement('div');
                productInfo.innerHTML = `
            <div>${cardBody.querySelector('.card-title').textContent}</div>
            <small class="text-muted">${cardBody.querySelector('.badge').textContent}</small>
        `;
                suggestion.appendChild(productInfo);

                suggestion.addEventListener('click', () => {
                    const productData = {
                        id: parseInt(card.dataset.id),
                        name: cardBody.querySelector('.card-title').textContent.trim(),
                        price: parseFloat(cardBody.querySelector('.badge').textContent.replace('$', '')),
                        product_barcode: card.dataset.barcode,
                        available_stock: parseInt(card.dataset.stock || '0'),
                        img: card.querySelector('.card-img-top').src
                    };

                    // Check stock before adding
                    const existingItem = bill.find(item => item.id === productData.id);
                    const newQuantity = existingItem ? existingItem.quantity + 1 : 1;

                    if (newQuantity > productData.available_stock) {
                        alert(`Insufficient stock for "${productData.name}". Available stock: ${productData.available_stock}`);
                        return;
                    }

                    addToBill(productData);
                    inputElement.value = '';
                    hideSuggestions();
                });

                suggestionsDiv.appendChild(suggestion);
            });

            // Insert suggestions after input
            inputElement.parentNode.style.position = 'relative';
            inputElement.parentNode.appendChild(suggestionsDiv);
        }

        // Hide suggestions dropdown
        function hideSuggestions() {
            const existing = document.querySelector('.suggestions-container');
            if (existing) existing.remove();
        }

        // Add click event listener to document to hide suggestions when clicking outside
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.search-bar-container')) {
                hideSuggestions();
            }
        });

        // Add these CSS styles to your stylesheet
        const styles = `
.suggestions-container {
    max-height: 300px;
    margin-top: 100px;
    overflow-y: auto;
}

.suggestion-item {
    cursor: pointer;
}

.suggestion-item:hover {
    background-color: #f8f9fa;
}

.search-bar-container {
    position: relative;
}

.suggestion-item small {
    font-size: 0.875em;
}
`;

        // Add styles to document
        const styleSheet = document.createElement('style');
        styleSheet.textContent = styles;
        document.head.appendChild(styleSheet);
    </script>


    <script>
        let bill = [];
        const beepSound = new Audio('/audio/beep.wav');

        // Update modal when opened
        document.getElementById('checkoutModal').addEventListener('show.bs.modal', updateModalContent);

        function updateModalContent() {
            const tbody = document.getElementById('modalBillItems');
            tbody.innerHTML = '';
            let total = 0;

            bill.forEach(item => {
                total += item.subtotal;
                tbody.innerHTML += `
            <tr>
                <td>${item.name}</td>
                <td>${item.quantity}</td>
                <td>$${item.price}</td>
                <td>$${item.subtotal}</td>
            </tr>
        `;
            });

            document.getElementById('modalTotalAmount').innerText = total.toFixed(2);
        }

        // Add item to bill
        function addToBill(product) {
            // Find the item in the bill if it already exists
            const existingItem = bill.find(item => item.id === product.id);

            // Calculate the total quantity if added
            const newQuantity = existingItem ? existingItem.quantity + 1 : 1;

            // Check if there is enough stock available
            if (newQuantity > product.available_stock) {
                alert(`Insufficient stock for "${product.name}". Available stock: ${product.available_stock}`);
                return;
            }

            // Play beep sound
            beepSound.play();

            // Add or update the product in the bill
            if (existingItem) {
                existingItem.quantity = newQuantity;
                existingItem.subtotal = existingItem.quantity * existingItem.price;
            } else {
                bill.push({
                    id: product.id,
                    name: product.name,
                    quantity: 1,
                    price: parseFloat(product.price),
                    subtotal: parseFloat(product.price),
                    available_stock: product.available_stock
                });
            }

            updateBillTable();
        }

        // Update bill table
        function updateBillTable() {
            const billItems = document.getElementById('billItems');
            billItems.innerHTML = '';
            let total = 0;

            bill.forEach(item => {
                total += item.subtotal;
                billItems.innerHTML += `
            <tr>
                <td>${item.name}</td>
                <td>${item.quantity}</td>
                <td>$${item.price}</td>
                <td>$${item.subtotal}</td>
                <td>
                    <button class="btn btn-danger btn-sm" onclick="removeFromBill(${item.id})">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            </tr>
        `;
            });

            document.getElementById('totalAmount').innerText = total.toFixed(2);
        }

        // Remove item from bill
        function removeFromBill(itemId) {
            bill = bill.filter(item => item.id !== itemId);
            updateBillTable();
        }

        // Finalize the checkout process
        function finalizeCheckout() {
            const receivedAmount = parseFloat(document.getElementById('receivedAmount').value) || 0;
            const totalAmount = parseFloat(document.getElementById('modalTotalAmount').innerText);

            if (receivedAmount < totalAmount) {
                alert('Insufficient payment');
                return;
            }

            const change = receivedAmount - totalAmount;
            document.getElementById('changeAmount').value = change.toFixed(2);

            // Deduct stock for each item in the bill
            bill.forEach(item => {
                const updatedStock = item.available_stock - item.quantity;

                // Send the updated stock to the server
                fetch(`/products/update-stock/${item.id}`, {
                    method: 'post',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        available_stock: updatedStock
                    }),
                }).catch(error => {
                    console.error('Error updating stock:', error);
                    alert(`Failed to update stock for "${item.name}".`);
                });
            });

            // Prepare sale data to save in the database
            const saleData = {
                receivedAmount: receivedAmount,
                totalAmount: totalAmount,
                changeAmount: change,
                date: new Date().toISOString(),
                items: bill
            };

            // Save the sale data
            fetch('/sales/save', {
                    method: 'post',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(saleData),
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Sale completed and saved to the database. Print the receipt!');
                        bill = []; // Clear the bill
                        updateBillTable();
                    } else {
                        alert('There was an error saving the sale. Please try again.');
                    }
                })
                .catch(error => {
                    console.error('Error saving sale:', error);
                    alert('There was an error processing your request.');
                });
        }

        function printBill() {
            const modalBillItems = document.getElementById('modalBillItems');
            const modalTotalAmountElement = document.getElementById('modalTotalAmount');

            if (!modalBillItems || !modalTotalAmountElement) {
                console.error('Modal elements not found');
                return; // Exit the function if elements are not found
            }

            const modalTotalAmount = modalTotalAmountElement.innerText;

            // Create printable content
            let printContent = `
    <div class='mx-auto'>
        <h3>Poslite</h3>
        <h5>Customer Invoice</h5>
        </div>
        <table border="1" style="width: 100%; border-collapse: collapse;">
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Qty</th>
                    <th>Price</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                ${modalBillItems.innerHTML}
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="3" class="text-end">Total:</th>
                    <th>$${modalTotalAmount}</th>
                </tr>
            </tfoot>
        </table>
        
    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSLMSy-RghVV9Ip3g7OBfu2lEZUjXVZUpdQYQ&s" alt="Barcode" style="width: 25%; text-align: center;">

        <h5>Thank You For Shopping!</h5>
    `;

            // Open a new window and write the print content
            const newWindow = window.open('', '', 'height=600,width=400');
            newWindow.document.write(printContent);
            newWindow.document.close();
            newWindow.print();
        }
    </script>

</body> 

</html>