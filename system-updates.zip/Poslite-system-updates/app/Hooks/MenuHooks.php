<?php

namespace App\Hooks;

use App\Libraries\MenuManager;
use CodeIgniter\Log\Logger;

class MenuHooks
{
    private static $menuStructure = [
        'Dashboard||1|dashboard|0' => [],
        'POS||5|pos|0' => [],
        // Dashboard Section
        'Products|shop|1' => [
                        [
                            'name' => 'Add Products',
                            'url' => 'product/add',
                            'icon' => 'plus-square-fill',
                            'icon_color' => '#28a745',
                            'position' => 1
                        ],
                        [
                            'name' => 'All Products',
                            'url' => 'datatable/all_products',
                            'icon' => 'grid-3x3-gap-fill',
                            'icon_color' => '#007bff',
                            'position' => 2
                        ],
                        [
                            'name' => 'Product Categories',
                            'url' => 'add_categories',
                            'icon' => 'diagram-3-fill',
                            'icon_color' => '#ffc107',
                            'position' => 3
                        ],
                        [
                            'name' => 'All Categories',
                            'url' => 'datatable/all_categories',
                            'icon' => 'folder2-open',
                            'icon_color' => '#17a2b8',
                            'position' => 4
                        ]
                    ],

                    'Inventory|box-seam-fill|2' => [
                        [
                            'name' => 'Manage Stock',
                            'url' => '/inventory/addAdjustment',
                            'icon' => 'stack',
                            'icon_color' => '#007bff',
                            'position' => 1
                        ],
                        [
                            'name' => 'Update Inventory',
                            'url' => '/inventory',
                            'icon' => 'arrow-repeat',
                            'icon_color' => '#28a745',
                            'position' => 2
                        ]
                    ],
                    'Expense|cash-stack|2' => [
                        [
                            'name' => 'Add Expense',
                            'url' => '/expenses/create',
                            'icon' => 'stack',
                            'icon_color' => '#007bff',
                            'position' => 1
                        ],
                        [
                            'name' => 'List Expenses',
                            'url' => '/expenses',
                            'icon' => 'arrow-repeat',
                            'icon_color' => '#28a745',
                            'position' => 2
                        ]
                    ],

                    'Purchases|bag-check-fill|3' => [
                        [
                            'name' => 'Add Purchase',
                            'url' => 'purchases/addPurchase',
                            'icon' => 'cart-plus-fill',
                            'icon_color' => '#007bff',
                            'position' => 1
                        ],
                        [
                            'name' => 'All Purchases',
                            'url' => 'datatable/allPurchases',
                            'icon' => 'card-list',
                            'icon_color' => '#28a745',
                            'position' => 2
                        ]
                    ],
                    'Brands|bag-check-fill|5' => [
                        [
                            'name' => 'Add Brand',
                            'url' => 'brands/create',
                            'icon' => 'cart-plus-fill',
                            'icon_color' => '#007bff',
                            'position' => 1
                        ],
                        [
                            'name' => 'All Brands',
                            'url' => 'datatable/brands',
                            'icon' => 'card-list',
                            'icon_color' => '#28a745',
                            'position' => 2
                        ]
                    ],

                    'Sales|cash-stack|4' => [
                        [
                            'name' => 'POS',
                            'url' => 'pos',
                            'icon' => 'calculator-fill',
                            'icon_color' => '#17a2b8',
                            'position' => 1
                        ],
                        [
                            'name' => 'Invoice History',
                            'url' => 'pos/invoice-history',
                            'icon' => 'file-text-fill',
                            'icon_color' => '#ffc107',
                            'position' => 2
                        ],
                    ],

                    'Vendors|building|5' => [
                        [
                            'name' => 'Add Vendor',
                            'url' => 'vendor/add',
                            'icon' => 'building-add',
                            'icon_color' => '#007bff',
                            'position' => 1
                        ],
                        [
                            'name' => 'All Vendors',
                            'url' => 'datatable/newvendor',
                            'icon' => 'buildings',
                            'icon_color' => '#28a745',
                            'position' => 2
                        ]
                    ],

                    'CRM|people|5' => [
                        [
                            'name' => 'Add Customer',
                            'url' => '/customers/create',
                            'icon' => 'person-add',
                            'icon_color' => '#007bff',
                            'position' => 1
                        ],
                        [
                            'name' => 'All Customer',
                            'url' => 'datatable/customers',
                            'icon' => 'person-lines-fill',
                            'icon_color' => '#28a745',
                            'position' => 2
                        ]
                    ],
                    'Warehouse|building|5' => [
                        [
                            'name' => 'Add Warehouse',
                            'url' => '/warehouses/create',
                            'icon' => 'building-add',
                            'icon_color' => '#007bff',
                            'position' => 1
                        ],
                        [
                            'name' => 'All Warehouse',
                            'url' => 'datatable/warehouses',
                            'icon' => 'buildings',
                            'icon_color' => '#28a745',
                            'position' => 2
                        ]
                    ],
                    'Units|percent|5' => [
                        [
                            'name' => 'Add Units',
                            'url' => '/units/create',
                            'icon' => 'plus-circle',
                            'icon_color' => '#007bff',
                            'position' => 1
                        ],
                        [
                            'name' => 'All Units',
                            'url' => 'datatable/units',
                            'icon' => 'peoples',
                            'icon_color' => '#28a745',
                            'position' => 2
                        ]
                    ],

                    'Quotations|file-earmark-text-fill|6' => [
                        [
                            'name' => 'Add Quotation',
                            'url' => '#',
                            'icon' => 'file-earmark-plus-fill',
                            'icon_color' => '#007bff',
                            'position' => 1
                        ],
                        [
                            'name' => 'All Quotations',
                            'url' => '#',
                            'icon' => 'files',
                            'icon_color' => '#28a745',
                            'position' => 2
                        ]
                    ],

                    'Stock Transfers|truck-front-fill|7' => [
                        [
                            'name' => 'Create Stock Transfers',
                            'url' => '#',
                            'icon' => 'box-arrow-right',
                            'icon_color' => '#007bff',
                            'position' => 1
                        ],
                        [
                            'name' => 'All Stock Transfers',
                            'url' => '#',
                            'icon' => 'arrows-move',
                            'icon_color' => '#28a745',
                            'position' => 2
                        ]
                    ],
                    
                    'Accounts|wallet-fill|9' => [
                        [
                            'name' => 'Create Accounts',
                            'url' => '#',
                            'icon' => 'journal-plus',
                            'icon_color' => '#007bff',
                            'position' => 1
                        ],
                        [
                            'name' => 'All Accounts',
                            'url' => '#',
                            'icon' => 'journals',
                            'icon_color' => '#28a745',
                            'position' => 2
                        ]
                    ],

                    'Reports|clipboard-data-fill|10' => [
                        [
                            'name' => 'Create Report',
                            'url' => '#',
                            'icon' => 'file-earmark-bar-graph',
                            'icon_color' => '#007bff',
                            'position' => 1
                        ],
                        [
                            'name' => 'All Reports',
                            'url' => '#',
                            'icon' => 'table',
                            'icon_color' => '#28a745',
                            'position' => 2
                        ]
                    ],
                    'Module Setting|puzzle-fill|10' => [
                        [
                            'name' => 'Add Module',
                            'url' => 'module-management',
                            'icon' => 'plus-square-dotted',
                            'icon_color' => '#28a745',
                            'position' => 1
                        ],
                    ],
                    'User Management|people-fill|9' => [
                        [
                            'name' => 'All Users',
                            'url' => 'datatable/user_list',
                            'icon' => 'person-lines-fill',
                            'icon_color' => '#007bff',
                            'position' => 1
                        ],
                        [
                            'name' => 'Register User',
                            'url' => 'user-register',
                            'icon' => 'person-plus-fill',
                            'icon_color' => '#28a745',
                            'position' => 2
                        ],
                        [
                            'name' => 'Roles & Permissions',
                            'url' => 'roles-permissions',
                            'icon' => 'shield-lock-fill',
                            'icon_color' => '#ffc107',
                            'position' => 3
                        ],
                        [
                            'name' => 'User Activity Log',
                            'url' => 'users/activity',
                            'icon' => 'clock-history',
                            'icon_color' => '#17a2b8',
                            'position' => 4
                        ]
                    ],
                    'Settings|gear-fill|10' => [
                        [
                            'name' => 'System Update',
                            'url' => 'version-management',
                            'icon' => 'cloud-arrow-up-fill',
                            'icon_color' => '#28a745',
                            'position' => 1
                        ],
                    ],
    ];

    public static function registerMenus()
    {
        try {
            $menuManager = MenuManager::getInstance();

            // Register the menu structure
            $menuManager->registerMenu(self::$menuStructure);

            // Initialize all registered menus
            $menuManager->initializeMenus();

            // Log successful menu registration
            log_message('info', 'Menu registration completed successfully');
        } catch (\Exception $e) {
            // Log detailed error information
            log_message('error', 'Menu registration failed: ' . $e->getMessage());
            log_message('error', 'Stack trace: ' . $e->getTraceAsString());

            // In development, you might want to throw the exception
            if (ENVIRONMENT === 'development') {
                throw $e;
            }
        }
    }

    /**
     * Helper method to get all registered menu slugs
     * Useful for permission seeding and validation
     */
    public static function getMenuSlugs(): array
    {
        $slugs = [];
        foreach (self::$menuStructure as $sectionKey => $items) {
            // Get section slug
            $sectionParts = explode('|', $sectionKey);
            $sectionSlug = $sectionParts[3] ?? null;

            if ($sectionSlug) {
                $slugs[] = "menu.{$sectionSlug}";
            }


            // Get item slugs
            foreach ($items as $item) {
                if (isset($item['slug'])) {
                    $slugs[] = "menu.item.{$item['slug']}";
                }
            }
        }
        return $slugs;
    }
}
