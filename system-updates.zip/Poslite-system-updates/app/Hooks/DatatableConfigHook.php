<?php

namespace App\Hooks;

use App\Models\DatatableConfigModel;

class DatatableConfigHook
{
    /**
     * Register default DataTable configurations dynamically.
     */
    public static function register()
    {
        $configModel = new DatatableConfigModel();

        // Define default tables
        $defaultTables = [
            [
                "table_title"=> "List of All Users",
                'table_name' => 'user_list',
                'api_endpoint' => 'fetch-all-users',
                'columns' => json_encode([
                    ['data'=> 'id','title'=> 'ID'],
                    ['data'=> 'username','title'=> 'Username'],
                    ['data'=> 'email','title'=> 'Email'],
                    ['data'=> 'created_at','title'=> 'Created At'],
                ])
            ],
        
            [
                "table_title"=> "List of All Products",
                'table_name' => 'all_products',
                'api_endpoint' => 'product',
                'columns' => json_encode([
                    ['data'=> 'id','title'=> 'ID'],
                    ['data'=> 'img','title'=> 'Image'],
                    ['data'=> 'name','title'=> 'Name'],
                    ['data'=> 'brand','title'=> 'Brand'],
                    ['data'=> 'category_name','title'=> 'Category'],
                    ['data'=> 'product_barcode','title'=> 'Barcode'],
                    ['data'=> 'product_unit','title'=> 'Unit'],
                    ['data'=> 'description','title'=> 'Description'],
                    ['data'=> 'available_stock','title'=> 'Stock'],
                    ['data'=> 'price','title'=> 'Price'],
                ])
            ],
            [
                "table_title"=> "List of All Categories",
                'table_name' => 'all_categories',
                'api_endpoint' => 'all_categories',
                'columns' => json_encode([
                    ['data'=> 'id','title'=> 'ID'],
                    ['data'=> 'name','title'=> 'Name'],

                ])
            ],
            [
                "table_title"=> "List of All Customers",
                'table_name' => 'customers',
                'api_endpoint' => 'customers',
                'columns' => json_encode([
                    ['data'=> 'id','title'=> 'ID'],
                    ['data'=> 'name','title'=> 'Name'],
                    ['data'=> 'email','title'=> 'Email'],
                    ['data'=> 'phone','title'=> 'Phone'],
                    ['data'=> 'address','title'=> 'Address'],

                ])
            ],
            [
                "table_title"=> "List of All Warehouses",
                'table_name' => 'warehouses',
                'api_endpoint' => 'warehouses',
                'columns' => json_encode([
                    ['data'=> 'id','title'=> 'ID'],
                    ['data'=> 'name','title'=> 'Name'],
                    ['data'=> 'location','title'=> 'Location'],
                    ['data'=> 'capacity','title'=> 'Capacity'],

                ])
            ],
            [
                "table_title"=> "List of All Vendors",
                'table_name' => 'newvendor',
                'api_endpoint' => 'newvendor',
                'columns' => json_encode([
                    ['data'=> 'id','title'=> 'ID'],
                    ['data'=> 'name','title'=> 'Name'],
                    ['data'=> 'email','title'=> 'Email'],
                    ['data'=> 'phone','title'=> 'Phone'],
                    ['data'=> 'address','title'=> 'Address'],

                ])
            ],
            [
                "table_title"=> "List of All Units",
                'table_name' => 'units',
                'api_endpoint' => 'units',
                'columns' => json_encode([
                    ['data'=> 'id','title'=> 'ID'],
                    ['data'=> 'name','title'=> 'Name'],
                    ['data'=> 'short_name','title'=> 'Short name'],
                    ['data'=> 'base_unit','title'=> 'Base unit'],
                    ['data'=> 'operate','title'=> 'Operate'],
                    ['data'=> 'operate_value','title'=> 'Operate Value'],

                ])
            ],
            [
                "table_title"=> "List of All Brands",
                'table_name' => 'brands',
                'api_endpoint' => 'brands',
                'columns' => json_encode([
                    ['data'=> 'id','title'=> 'ID'],
                    ['data'=> 'name','title'=> 'Name'],

                ])
            ],

            [
                "table_title"=> "List of All Purchases",
                'table_name' => 'allPurchases',
                'api_endpoint' => 'purchases/allPurchases',
                'columns' => json_encode([
                    
                    ['data'=> 'id','title'=> 'ID'],
                    ['data'=> 'vendor_id','title'=> 'Vendor'],
                    ['data'=> 'purchase_date','title'=> 'Date'],
                    ['data'=> 'total_amount','title'=> 'Total Amount'],
                    ['data'=> 'pay_amount','title'=> 'Pay Amount'],
                    ['data'=> 'pending_amount','title'=> 'Pending Amount'],
                    ['data'=> 'warehouse_id','title'=> 'Warehouse'],

                ])
            ],
        ];

        // Insert default configurations if not already present
        foreach ($defaultTables as $table) {
            $existing = $configModel->where('table_name', $table['table_name'])->first();
            if (!$existing) {
                $configModel->insert($table);
            }
        }
    }
}
