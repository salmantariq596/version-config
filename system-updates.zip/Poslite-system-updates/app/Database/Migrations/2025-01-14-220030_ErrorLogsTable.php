<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateErrorLogsTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type' => 'BIGINT',
                'unsigned' => true,
                'auto_increment' => true
            ],
            'error_type' => [
                'type' => 'VARCHAR',
                'constraint' => 255
            ],
            'error_message' => [
                'type' => 'TEXT'
            ],
            'file_path' => [
                'type' => 'VARCHAR',
                'constraint' => 512
            ],
            'line_number' => [
                'type' => 'INT'
            ],
            'stack_trace' => [
                'type' => 'TEXT'
            ],
            'server_data' => [
                'type' => 'TEXT'
            ],
            'request_data' => [
                'type' => 'TEXT'
            ],
            'user_id' => [
                'type' => 'INT',
                'null' => true
            ],
            'ip_address' => [
                'type' => 'VARCHAR',
                'constraint' => 45
            ],
            'user_agent' => [
                'type' => 'VARCHAR',
                'constraint' => 255
            ],
            'severity' => [
                'type' => 'VARCHAR',
                'constraint' => 20
            ],
            'http_code' => [
                'type' => 'SMALLINT'
            ],
            'url' => [
                'type' => 'VARCHAR',
                'constraint' => 512
            ],
            'request_method' => [
                'type' => 'VARCHAR',
                'constraint' => 10
            ],
            'created_at' => [
                'type' => 'DATETIME'
            ]
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addKey(['created_at']);
        $this->forge->addKey(['severity']);
        $this->forge->createTable('error_logs');
    }

    public function down()
    {
        $this->forge->dropTable('error_logs');
    }
}