<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AlterPermissionsTable extends Migration
{
    public function up()
    {
        // Step 1: Add the column without constraints
        $fields = [
            'slug' => [
                'type' => 'VARCHAR',
                'constraint' => 255,
                'null' => true, // Allow null temporarily
                'after' => 'name',
            ],
        ];
        $this->forge->addColumn('permissions', $fields);

        // Step 2: Populate the column with unique values for existing rows
        $builder = $this->db->table('permissions');
        $permissions = $builder->get()->getResult();
        foreach ($permissions as $permission) {
            $builder->update(['slug' => 'slug_' . $permission->id], ['id' => $permission->id]);
        }

        // Step 3: Modify the column to add constraints
        $this->forge->modifyColumn('permissions', [
            'slug' => [
                'type' => 'VARCHAR',
                'constraint' => 255,
                'null' => false, // Now make it NOT NULL
                'unique' => true, // Add unique constraint
            ],
        ]);

        // Step 4: Add indexes
        $this->forge->addKey('slug');
    }

    public function down()
    {
        $this->forge->dropColumn('permissions', 'slug');
    }
}
