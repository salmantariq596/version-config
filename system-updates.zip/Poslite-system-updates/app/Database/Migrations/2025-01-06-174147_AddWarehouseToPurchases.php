<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddWarehouseToPurchases extends Migration
{
    public function up()
    {
        $this->forge->addColumn('purchases', [
            'warehouse_id' => [
                'type'       => 'INT',
                'constraint' => 11, 
                'unsigned'  => true, 
                'null'       => true, 
            ],
        ]);

        // Add foreign key constraint (optional)
        $this->forge->addForeignKey('warehouse_id', 'warehouses', 'id', 'CASCADE', 'SET NULL'); 
    }

    public function down()
    {
        // Drop the foreign key constraint (if added)
        $this->forge->dropForeignKey('purchases', 'purchases_warehouse_id_foreign'); 

        $this->forge->dropColumn('purchases', 'warehouse_id');
    }
}
