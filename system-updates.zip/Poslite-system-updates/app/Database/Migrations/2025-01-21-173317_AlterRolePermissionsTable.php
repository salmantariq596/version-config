<?php
// app/Database/Migrations/[timestamp]_AlterRolePermissionsTable.php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AlterRolePermissionsTable extends Migration
{
    public function up()
    {
        // Remove duplicates
        $this->db->query("
            DELETE rp1
            FROM role_permissions rp1
            INNER JOIN role_permissions rp2
            WHERE rp1.role_id = rp2.role_id
              AND rp1.permission_id = rp2.permission_id
              AND rp1.id > rp2.id
        ");

        // Add unique constraint
        $this->db->query("
            ALTER TABLE role_permissions
            ADD CONSTRAINT unique_role_permission UNIQUE (role_id, permission_id)
        ");
    }

    public function down()
    {
        $this->db->query("
            ALTER TABLE role_permissions
            DROP INDEX unique_role_permission
        ");
    }
}
