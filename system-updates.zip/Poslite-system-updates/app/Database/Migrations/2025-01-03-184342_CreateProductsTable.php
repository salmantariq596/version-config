<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateProductsTable extends Migration
{
    public function up()
    {
        // Create 'products' table
        $this->forge->addField([
            'id'                => [
                'type'           => 'INT',
                'unsigned'      => true,
                'auto_increment' => true,
            ],
            'name'              => [
                'type'           => 'VARCHAR',
                'constraint'     => '255',
            ],
            'brand'             => [
                'type'           => 'VARCHAR',
                'constraint'     => '255',
            ],
            'tax'               => [
                'type'           => 'FLOAT',
                'null'           => true,
            ],
            'tax-type'          => [
                'type'           => 'VARCHAR',
                'constraint'     => '50',
                'null'           => true,
            ],
            'product_type'      => [
                'type'           => 'VARCHAR',
                'constraint'     => '100',
            ],
            'product_unit'      => [
                'type'           => 'VARCHAR',
                'constraint'     => '50',
            ],
            'purchase_unit'     => [
                'type'           => 'VARCHAR',
                'constraint'     => '50',
            ],
            'sale_unit'         => [
                'type'           => 'VARCHAR',
                'constraint'     => '50',
            ],
            'stock_alert'       => [
                'type'           => 'INT',
                'unsigned'      => true,
                'null'           => true,
            ],
            'category_id'       => [
                'type'           => 'INT',
                'unsigned'      => true,
                'null'           => true, // Allow null initially
            ],
            'price'             => [
                'type'           => 'DECIMAL',
                'constraint'     => '10,2',
            ],
            'img'               => [
                'type'           => 'VARCHAR',
                'constraint'     => '255',
                'null'           => true,
            ],
            'product_barcode'   => [
                'type'           => 'VARCHAR',
                'constraint'     => '255',
                'null'           => true,
            ],
            'description'       => [
                'type'           => 'TEXT',
                'null'           => true,
            ],
            'available_stock'   => [
                'type'           => 'INT',
                'unsigned'      => true,
                'default'        => 0,
            ],
        ]);
        
        // Set primary key
        $this->forge->addPrimaryKey('id');

        // Create the products table
        $this->forge->createTable('products');
    }

    public function down()
    {
        // Drop the products table
        $this->forge->dropTable('products');
    }
}
