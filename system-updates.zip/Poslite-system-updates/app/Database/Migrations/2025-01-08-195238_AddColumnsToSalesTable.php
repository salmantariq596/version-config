<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddColumnsToSalesTable extends Migration
{
    public function up()
    {
        $fields = [
            
            'payment_method' => [
                'type' => 'VARCHAR',
                'constraint' => 50,
                'null' => true,
            ],
            'received_amount' => [
                'type' => 'DECIMAL',
                'constraint' => '10,2',
                'null' => true,
            ],
            'change_amount' => [
                'type' => 'DECIMAL',
                'constraint' => '10,2',
                'null' => true,
            ],
        ];

        // Add columns to the sales table
        $this->forge->addColumn('sales', $fields);
    }

    public function down()
    {
        // Remove columns from the sales table
        $this->forge->dropColumn('sales', [ 'payment_method', 'received_amount','change_amount']);
    }
}
