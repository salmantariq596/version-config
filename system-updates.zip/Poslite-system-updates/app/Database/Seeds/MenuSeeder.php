<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class MenuSeeder extends Seeder
{
    public function run()
    {
        // First, let's define our menu sections
        $menuSections = [
            [
                'name' => 'Products',
                'icon' => 'cart-check',
                'order_position' => 1,
                'active' => true
            ],
            [
                'name' => 'Inventory',
                'icon' => 'boxes',
                'order_position' => 2,
                'active' => true
            ],
            [
                'name' => 'Purchases',
                'icon' => 'boxes',
                'order_position' => 3,
                'active' => true
            ],
            [
                'name' => 'Sales',
                'icon' => 'receipt-cutoff',
                'order_position' => 4,
                'active' => true
            ],
            [
                'name' => 'Vendors',
                'icon' => 'check2-all',
                'order_position' => 5,
                'active' => true
            ],
            [
                'name' => 'Quotations',
                'icon' => 'quote',
                'order_position' => 6,
                'active' => true
            ],
            [
                'name' => 'Stock Transfers',
                'icon' => 'truck',
                'order_position' => 7,
                'active' => true
            ],
            [
                'name' => 'Stock Adjustment',
                'icon' => 'sliders',
                'order_position' => 8,
                'active' => true
            ],
            [
                'name' => 'Accounts',
                'icon' => 'person-badge',
                'order_position' => 9,
                'active' => true
            ],
            [
                'name' => 'Reports',
                'icon' => 'file-earmark-bar-graph',
                'order_position' => 10,
                'active' => true
            ]
        ];

        // Insert menu sections
        $this->db->table('menu_sections')->insertBatch($menuSections);

        // Now let's define menu items for each section
        $menuItems = [
            // Products Section Items
            [
                'section_id' => 1,
                'name' => 'Add Products',
                'icon' => 'plus-circle-fill',
                'url' => 'product/add',
                'icon_color' => '#28a745',
                'order_position' => 1,
                'active' => true
            ],
            [
                'section_id' => 1,
                'name' => 'All Products',
                'icon' => 'box-fill',
                'url' => 'product',
                'icon_color' => '#007bff',
                'order_position' => 2,
                'active' => true
            ],
            [
                'section_id' => 1,
                'name' => 'Product Categories',
                'icon' => 'tags-fill',
                'url' => 'add_categories',
                'icon_color' => '#ffc107',
                'order_position' => 3,
                'active' => true
            ],
            [
                'section_id' => 1,
                'name' => 'All Categories',
                'icon' => 'folder-fill',
                'url' => 'all_categories',
                'icon_color' => '#17a2b8',
                'order_position' => 4,
                'active' => true
            ],

            // Inventory Section Items
            [
                'section_id' => 2,
                'name' => 'Manage Stock',
                'icon' => 'boxes',
                'url' => '#',
                'icon_color' => '#007bff',
                'order_position' => 1,
                'active' => true
            ],
            [
                'section_id' => 2,
                'name' => 'Update Inventory',
                'icon' => 'arrow-clockwise',
                'url' => '#',
                'icon_color' => '#28a745',
                'order_position' => 2,
                'active' => true
            ],

            // Purchases Section Items
            [
                'section_id' => 3,
                'name' => 'Add Purchase',
                'icon' => 'plus-circle',
                'url' => 'purchases/addPurchase',
                'icon_color' => '#007bff',
                'order_position' => 1,
                'active' => true
            ],
            [
                'section_id' => 3,
                'name' => 'All Purchases',
                'icon' => 'boxes',
                'url' => 'purchases/allPurchases',
                'icon_color' => '#28a745',
                'order_position' => 2,
                'active' => true
            ],

            // Sales Section Items
            [
                'section_id' => 4,
                'name' => 'POS',
                'icon' => 'cash-coin',
                'url' => 'pos',
                'icon_color' => '#17a2b8',
                'order_position' => 1,
                'active' => true
            ],
            [
                'section_id' => 4,
                'name' => 'Invoice History',
                'icon' => 'receipt',
                'url' => '#',
                'icon_color' => '#ffc107',
                'order_position' => 2,
                'active' => true
            ],
            [
                'section_id' => 4,
                'name' => 'All Sales',
                'icon' => 'cart-check',
                'url' => '#',
                'icon_color' => '#28a745',
                'order_position' => 3,
                'active' => true
            ],

            // Vendors Section Items
            [
                'section_id' => 5,
                'name' => 'Add Vendor',
                'icon' => 'person-plus',
                'url' => 'vendor/add',
                'icon_color' => '#007bff',
                'order_position' => 1,
                'active' => true
            ],
            [
                'section_id' => 5,
                'name' => 'All Vendors',
                'icon' => 'person-lines-fill',
                'url' => 'vendor',
                'icon_color' => '#28a745',
                'order_position' => 2,
                'active' => true
            ],

            // Quotations Section Items
            [
                'section_id' => 6,
                'name' => 'Add Quotation',
                'icon' => 'person-plus',
                'url' => '#',
                'icon_color' => '#007bff',
                'order_position' => 1,
                'active' => true
            ],
            [
                'section_id' => 6,
                'name' => 'All Quotations',
                'icon' => 'person-lines-fill',
                'url' => '#',
                'icon_color' => '#28a745',
                'order_position' => 2,
                'active' => true
            ],

            // Stock Transfers Section Items
            [
                'section_id' => 7,
                'name' => 'Create Stock Transfers',
                'icon' => 'arrow-left-right',
                'url' => '#',
                'icon_color' => '#007bff',
                'order_position' => 1,
                'active' => true
            ],
            [
                'section_id' => 7,
                'name' => 'All Stock Transfers',
                'icon' => 'box-arrow-in-up-right',
                'url' => '#',
                'icon_color' => '#28a745',
                'order_position' => 2,
                'active' => true
            ],

            // Stock Adjustment Section Items
            [
                'section_id' => 8,
                'name' => 'Create Stock Adjustment',
                'icon' => 'plus-circle',
                'url' => '#',
                'icon_color' => '#007bff',
                'order_position' => 1,
                'active' => true
            ],
            [
                'section_id' => 8,
                'name' => 'All Stock Adjustment',
                'icon' => 'list-check',
                'url' => '#',
                'icon_color' => '#28a745',
                'order_position' => 2,
                'active' => true
            ],

            // Accounts Section Items
            [
                'section_id' => 9,
                'name' => 'Create Accounts',
                'icon' => 'person-circle',
                'url' => '#',
                'icon_color' => '#007bff',
                'order_position' => 1,
                'active' => true
            ],
            [
                'section_id' => 9,
                'name' => 'All Accounts',
                'icon' => 'people',
                'url' => '#',
                'icon_color' => '#28a745',
                'order_position' => 2,
                'active' => true
            ],

            // Reports Section Items
            [
                'section_id' => 10,
                'name' => 'Create Report',
                'icon' => 'person-circle',
                'url' => '#',
                'icon_color' => '#007bff',
                'order_position' => 1,
                'active' => true
            ],
            [
                'section_id' => 10,
                'name' => 'All Reports',
                'icon' => 'people',
                'url' => '#',
                'icon_color' => '#28a745',
                'order_position' => 2,
                'active' => true
            ]
        ];

        // Insert menu items
        $this->db->table('menu_items')->insertBatch($menuItems);
    }
}