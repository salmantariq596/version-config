<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class RolesSeeder extends Seeder
{
    public function run()
    {
        $role = [
            'name' => 'SuperAdmin',
            'slug' => 'super-admin',
            'description' => 'Full access',
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        // Check if the SuperAdmin role already exists
        $exists = $this->db->table('roles')
                          ->where('slug', 'super-admin')
                          ->countAllResults();

        if (!$exists) {
            $this->db->table('roles')->insert($role);
        }
    }
}