<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class PermissionsSeeder extends Seeder
{
    public function run()
    {
        $permissions = [
            // Dashboard Permissions
            ['name' => 'View Dashboard', 'slug' => 'view-dashboard', 'description' => 'Access to view dashboard'],
            
            // Module Management
            ['name' => 'Manage Modules', 'slug' => 'manage-modules', 'description' => 'Full access to module management'],
            
            // User Management
            ['name' => 'Manage Users', 'slug' => 'manage-users', 'description' => 'Full access to user management'],
            
            // Roles & Permissions
            ['name' => 'Manage Roles', 'slug' => 'manage-roles', 'description' => 'Full access to roles and permissions'],
            
            // Products
            ['name' => 'Manage Products', 'slug' => 'manage-products', 'description' => 'Full access to product management'],
            
            // Inventory
            ['name' => 'Manage Inventory', 'slug' => 'manage-inventory', 'description' => 'Full access to inventory management'],
            
            // Purchases
            ['name' => 'Manage Purchases', 'slug' => 'manage-purchases', 'description' => 'Full access to purchase management'],
            
            // Expenses
            ['name' => 'Manage Expenses', 'slug' => 'manage-expenses', 'description' => 'Full access to expense management'],
            
            // POS
            ['name' => 'Access POS', 'slug' => 'access-pos', 'description' => 'Can access POS system'],
            
            // Vendors
            ['name' => 'Manage Vendors', 'slug' => 'manage-vendors', 'description' => 'Full access to vendor management'],
            
            // Customers
            ['name' => 'Manage Customers', 'slug' => 'manage-customers', 'description' => 'Full access to customer management'],
            
            // Warehouses
            ['name' => 'Manage Warehouses', 'slug' => 'manage-warehouses', 'description' => 'Full access to warehouse management'],
            
            // Units
            ['name' => 'Manage Units', 'slug' => 'manage-units', 'description' => 'Full access to units management'],
            
            // Brands
            ['name' => 'Manage Brands', 'slug' => 'manage-brands', 'description' => 'Full access to brands management'],
            
            // Version Management
            ['name' => 'Manage Versions', 'slug' => 'manage-versions', 'description' => 'Access to version management'],
        ];

        // Insert permissions
        $this->db->table('permissions')->insertBatch($permissions);

        // Create default role (Super Admin)
        $roleData = [
            'name' => 'Super Admin',
            'slug' => 'super-admin',
            'description' => 'Full system access'
        ];
        
        $this->db->table('roles')->insert($roleData);
        $roleId = $this->db->insertID();

        // Assign all permissions to Super Admin
        $rolePermissions = [];
        foreach ($permissions as $permission) {
            $permissionId = $this->db->table('permissions')
                                   ->where('slug', $permission['slug'])
                                   ->get()
                                   ->getRow()
                                   ->id;
                                   
            $rolePermissions[] = [
                'role_id' => $roleId,
                'permission_id' => $permissionId
            ];
        }

        $this->db->table('role_permissions')->insertBatch($rolePermissions);
    }
}