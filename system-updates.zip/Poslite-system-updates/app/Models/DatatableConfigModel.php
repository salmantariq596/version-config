<?php

namespace App\Models;

use CodeIgniter\Model;

class DatatableConfigModel extends Model
{
    protected $table = 'datatable_config';
    protected $primaryKey = 'id';
    protected $allowedFields = ['table_name', 'table_title', 'api_endpoint', 'columns', 'created_at', 'updated_at'];
    protected $useTimestamps = true;

    public function getConfigByTableName($tableName)
    {
        return $this->where('table_name', $tableName)->first();
    }
}
