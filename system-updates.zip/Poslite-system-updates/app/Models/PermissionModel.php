<?php

namespace App\Models;

use CodeIgniter\Model;

class PermissionModel extends Model
{
    protected $table            = 'permissions';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ['name', 'description', 'slug'];

    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    protected $validationRules = [
        'name' => 'required|min_length[3]|max_length[255]|is_unique[permissions.name,id,{id}]',
        'description' => 'required|min_length[3]',
        'slug' => 'required|alpha_dash|min_length[3]|max_length[255]|is_unique[permissions.slug,id,{id}]'
    ];

    protected $validationMessages = [
        'name' => [
            'required' => 'Permission name is required',
            'is_unique' => 'Permission name must be unique'
        ],
        'slug' => [
            'required' => 'Permission slug is required',
            'is_unique' => 'Permission slug must be unique',
            'alpha_dash' => 'Slug can only contain alphanumeric characters, dashes, and underscores'
        ]
    ];

    // Remove the automatic slug generation since we're handling it manually in MenuManager
    // protected $beforeInsert = ['createSlug'];
    // protected $beforeUpdate = ['createSlug'];

    public function getRoles($permissionId)
    {
        return $this->db->table('role_permissions')
            ->join('roles', 'roles.id = role_permissions.role_id')
            ->where('permission_id', $permissionId)
            ->get()
            ->getResultArray();
    }
}