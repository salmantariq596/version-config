<?php

namespace App\Models;

use CodeIgniter\Model;

class CategoryModel extends Model
{
    protected $table = 'categories'; // Table name
    protected $primaryKey = 'id';    // Primary key column
    protected $allowedFields = ['name', 'created_at', 'updated_at']; // Columns allowed for insert/update
public $useTimestamps = true; // Enable automatic handling of created_at and updated_at

    // Optionally, you can add validation rules here
    protected $validationRules = [
        'name' => 'required|min_length[3]|max_length[255]'
    ];
}
