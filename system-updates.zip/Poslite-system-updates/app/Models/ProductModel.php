<?php

namespace App\Models;

use CodeIgniter\Model;

class ProductModel extends Model
{
    protected $table = 'products';
    protected $primaryKey = 'id';
    protected $allowedFields = ['name', 'brand', 'tax', 'tax-type', 'product_type', 'product_unit', 'purchase_unit', 'sale_unit', 'stock_alert', 'category_id', 'price', 'img', 'product_barcode', 'description', 'available_stock'];
    protected $useTimestamps = false;

    public function getProducts()
    {
        return $this->findAll();
    }

    public function getProductById($id)
    {
        return $this->find($id);
    }

    public function updateStock($product_id, $quantity)
    {
        $product = $this->find($product_id);
        if ($product) {
            $newStock = $product['available_stock'] + $quantity; // Use 'available_stock' here
            $this->update($product_id, ['available_stock' => $newStock]); // Update 'available_stock'
        }
    }
}
