<?php

namespace App\Models;

use CodeIgniter\Model;

class PurchaseDetailModel extends Model
{
    protected $table      = 'purchase_details';
    protected $primaryKey = 'id';
    protected $allowedFields = ['purchase_id', 'product_id', 'quantity', 'price'];

    // Function to get all details for a purchase
    public function getDetailsByPurchaseId($purchase_id)
    {
        return $this->where('purchase_id', $purchase_id)->findAll();
    }
}
