<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table            = 'users';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ['role_id', 'username', 'email', 'password'];

    protected bool $allowEmptyInserts = false;
    protected bool $updateOnlyChanged = true;

    protected array $casts = [];
    protected array $castHandlers = [];

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    // Validation
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert   = [];
    protected $afterInsert    = [];
    protected $beforeUpdate   = [];
    protected $afterUpdate    = [];
    protected $beforeFind     = [];
    protected $afterFind      = [];
    protected $beforeDelete   = [];
    protected $afterDelete    = [];

    protected $validationRules = [
        'role_id' => 'permit_empty|integer|is_not_unique[roles.id]'
    ];

    public function getRole($userId)
    {
        return $this->db->table('roles')
            ->join('users', 'users.role_id = roles.id')
            ->where('users.id', $userId)
            ->get()
            ->getRowArray();
    }

    public function hasPermission($userId, $permissionSlug)
    {
        return $this->db->table('users')
            ->join('roles', 'roles.id = users.role_id')
            ->join('role_permissions', 'role_permissions.role_id = roles.id')
            ->join('permissions', 'permissions.id = role_permissions.permission_id')
            ->where('users.id', $userId)
            ->where('permissions.slug', $permissionSlug)
            ->countAllResults() > 0;
    }

    public function getAllPermissions($userId)
    {
        return $this->db->table('permissions')
            ->join('role_permissions', 'role_permissions.permission_id = permissions.id')
            ->join('roles', 'roles.id = role_permissions.role_id')
            ->join('users', 'users.role_id = roles.id')
            ->where('users.id', $userId)
            ->get()
            ->getResultArray();
    }
}
