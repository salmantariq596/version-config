<?php

namespace App\Models;

use CodeIgniter\Model;

class AppVersion extends Model
{
    protected $table            = 'app_versions';
    protected $primaryKey       = 'id';
    protected $allowedFields    = ['version', 'last_checked'];
    protected $returnType       = 'object';
    protected $useTimestamps    = true;
    protected $createdField     = 'created_at';
    protected $updatedField     = 'updated_at';

    protected $validationRules = [
        'version' => 'required|regex_match[/^\d+\.\d+\.\d+$/]|is_unique[app_versions.version]'
    ];

    public function getCurrentVersion(): ?string
    {
        $result = $this->orderBy('created_at', 'DESC')->first();
        return $result ? $result->version : null;
    }

    public function recordVersionCheck(string $version): void
    {
        $this->where('version', $version)
            ->set(['last_checked' => date('Y-m-d H:i:s')])
            ->update();
    }
}
