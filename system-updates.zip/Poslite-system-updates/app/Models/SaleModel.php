<?php

namespace App\Models;

use CodeIgniter\Model;

class SaleModel extends Model
{
    protected $table = 'sales';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'customer_id',
        'warehouse_id',
        'received_amount',
        'total_amount',
        'change_amount',
        'payment_method',
        'sale_date',
        'created_at',
        'updated_at'
    ];
    public function insertSale($data) 
    {
        return $this->insert($data);
    }


    public function getTotalSales()
    {
        return $this->selectSum('total_amount')->get()->getRow()->total_amount ?? 0;
    }
}


?>