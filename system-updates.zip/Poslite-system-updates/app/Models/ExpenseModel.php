<?php

namespace App\Models;

use CodeIgniter\Model;

class ExpenseModel extends Model
{
    protected $table = 'expenses';
    protected $primaryKey = 'id';
    protected $allowedFields = ['expense_date', 'category', 'amount', 'description'];
    protected $useTimestamps = true;
    
    protected $validationRules = [
        'expense_date' => 'required|valid_date',
        'category'     => 'required|min_length[3]|max_length[100]',
        'amount'       => 'required|numeric',
        'description'  => 'permit_empty|min_length[5]|max_length[500]'
    ];

    public function getTotalExpenses()
    {
        return $this->selectSum('amount')->get()->getRow()->amount ?? 0;
    }
}
