<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\AppVersion;
use CodeIgniter\HTTP\ResponseInterface;

class VersionController extends BaseController
{
    private const CACHE_KEY = 'version_config';
    private const CACHE_TTL = 30; // 5 minutes
    private const MAX_RETRIES = 2;
    private const REQUEST_TIMEOUT = 15;

    private $cache;
    private $versionModel;

    public function __construct()
    {
        $this->cache = \Config\Services::cache();
        $this->versionModel = new AppVersion();
    }

    public function index()
    {
        $currentVersion = $this->versionModel->getCurrentVersion();
        $versionHistory = $this->versionModel->orderBy('created_at', 'DESC')->findAll();

        return $this->render('versions/version_list', [
            'current_version' => $currentVersion,
            'versions' => $versionHistory
        ]);
    }

    public function checkVersion(): ResponseInterface
    {
        try {
            $config = $this->fetchVersionConfig();

            if (!$config['success']) {
                return $this->respondError($config['message'], ResponseInterface::HTTP_SERVICE_UNAVAILABLE);
            }

            return $this->respondSuccess($config['data']);
        } catch (\Exception $e) {
            log_message('error', 'Version check failed: ' . $e->getMessage());
            return $this->respondError('Internal server error', ResponseInterface::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    private function fetchVersionConfig(): array
    {
        // if ($cached = $this->cache->get(self::CACHE_KEY)) {
        //     return ['success' => true, 'data' => $cached];
        // }

        $remoteConfig = $this->fetchRemoteConfigWithRetry();

        if (!$remoteConfig) {
            return ['success' => false, 'message' => 'Failed to fetch remote configuration'];
        }

        $processed = $this->processConfig($remoteConfig);
        $this->cache->save(self::CACHE_KEY, $processed, self::CACHE_TTL);

        return ['success' => true, 'data' => $processed];
    }

    private function processConfig(array $config): array
    {
        $currentVersion = $this->versionModel->getCurrentVersion();
        $remoteVersion = $config['version'];

        // Add debug logging
        log_message('debug', "Version check - Current: {$currentVersion}, Remote: {$remoteVersion}");

        $comparison = version_compare($remoteVersion, $currentVersion ?? '0.0.0');

        return [
            'current_version' => $currentVersion,
            'remote_version' => $remoteVersion,
            'status' => $this->getStatus($comparison),
            'message' => $this->getMessage($comparison, $config),
            'requires_update' => $comparison > 0, // Only true when remote > current
            'last_checked' => date('Y-m-d H:i:s'),
        ];
    }

    private function getStatus(int $comparison): string
    {
        return match ($comparison) {
            1 => 'update_available',
            0 => 'current',
            -1 => 'downgrade_recommended'
        };
    }

    private function getMessage(int $comparison, array $config): string
    {
        return match ($comparison) {
            1 => $config['update_message'] ?? 'New version available',
            0 => 'System is up to date',
            -1 => $config['downgrade_message'] ?? 'Local version is newer'
        };
    }

    public function performUpdate(): ResponseInterface
    {
        try {
            $config = $this->fetchVersionConfig();

            if (!$config['success'] || !$config['data']['requires_update']) {
                return $this->respondError('No update available', ResponseInterface::HTTP_BAD_REQUEST);
            }

            $this->versionModel->insert(['version' => $config['data']['remote_version']]);
            $this->versionModel->recordVersionCheck($config['data']['remote_version']);

            // Clear cache after update
            $this->cache->delete(self::CACHE_KEY);

            return $this->respondSuccess([
                'message' => 'Update successful: ' . $config['data']['message'],
                'new_version' => $config['data']['remote_version']
            ]);
        } catch (\Exception $e) {
            log_message('error', 'Update failed: ' . $e->getMessage());
            return $this->respondError('Update operation failed', ResponseInterface::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    private function respondSuccess($data, int $code = 200): ResponseInterface
    {
        return $this->response
            ->setStatusCode($code)
            ->setContentType('application/json')
            ->setJSON([
                'success' => true,
                'data' => $data
            ]);
    }

    private function respondError(string $message, int $code): ResponseInterface
    {
        return $this->response
            ->setStatusCode($code)
            ->setContentType('application/json')
            ->setJSON([
                'success' => false,
                'error' => $message
            ]);
    }

    private function makeHttpRequest(string $url): array
    {
        $ch = curl_init();

        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 3,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_2TLS,
            CURLOPT_HTTPHEADER => [
                'Accept: application/json',
                'Accept-Language: en-US,en;q=0.9',
                'Cache-Control: no-cache'
            ],
            CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36'
        ]);

        $response = curl_exec($ch);
        $error = curl_error($ch);
        $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        curl_close($ch);

        if ($error) {
            throw new \RuntimeException("CURL error: {$error}");
        }

        return [
            'status' => $statusCode,
            'body' => $response
        ];
    }

    private function fetchRemoteConfigWithRetry(): ?array
    {
        $retryCount = 0;
        $configUrl = getenv('app.config_file_path');

        do {
            try {
                $response = $this->makeHttpRequest($configUrl);

                // Handle GitHub rate limits
                if ($response['status'] === 403 && str_contains($response['body'], 'rate limit')) {
                    log_message('warning', 'GitHub rate limit exceeded');
                    sleep(pow(2, $retryCount)); // Exponential backoff
                    continue;
                }

                if ($response['status'] === 200) {
                    return json_decode($response['body'], true);
                }
            } catch (\Exception $e) {
                log_message('error', 'CURL error: ' . $e->getMessage());
            }

            // Add delay between retries
            usleep(500000 * $retryCount); // 0.5s * retryCount

        } while ($retryCount++ < self::MAX_RETRIES);

        return null;
    }
}
