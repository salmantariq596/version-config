<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;
use App\Models\MenuItemModel;
use App\Models\RolePermissionModel;
use App\Models\UserModel;
use App\Models\PermissionModel;

abstract class BaseController extends Controller
{
    protected $request;
    protected $userModel;
    protected $viewData = [];

    public function __construct()
    {
        $this->request = \Config\Services::request();
        $this->userModel = new UserModel();
    }

    public function filterMenuDataByPermissions($menuData, $userPermissions)
    {
        $filteredMenuData = [];

        foreach ($menuData as $section) {
            // Check if the section slug is in user permissions
            if (in_array($section['slug'], $userPermissions)) {
                $filteredMenuData[] = $section;
            } else {
                // If section slug is not in permissions, filter its items
                $filteredItems = array_filter($section['items'], function ($item) use ($userPermissions) {
                    // If the section has no items matching user permissions, skip it
                    return !empty($item['slug']) && in_array($item['slug'], $userPermissions);
                });

                // If there are filtered items, add the section with those items
                if (!empty($filteredItems)) {
                    $sectionCopy = $section;
                    $sectionCopy['items'] = $filteredItems;
                    $filteredMenuData[] = $sectionCopy;
                }
            }
        }

        return $filteredMenuData;
    }

    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
    {
        parent::initController($request, $response, $logger);

        // Get user permissions
        $userPermissions = $this->getUserPermissions();

        // Load menu data with user permissions
        $menuModel = new MenuItemModel();
        $menuData = $menuModel->getAllMenuData();

        // Filter menu data based on user permissions
        $filteredMenuData = $this->filterMenuDataByPermissions($menuData, $userPermissions);

        $this->viewData['menuData'] = $filteredMenuData;
    }

    protected function getUserPermissions(): array
    {
        $session = session();
        $user = $session->get('user');

        // If no user is logged in, return empty permissions array
        if (!$user) {
            return [];
        }

        // Check if user is a superadmin
        $userModel = new UserModel();
        $userDetails = $userModel->find($user['id']);


        // If user is a superadmin, return all possible permissions
        if ($userDetails && $userDetails['username'] == 'admin') { // Assuming role_id 1 is superadmin
            $permissionModel = new PermissionModel(); // You'll need to create this model
            $allPermissions = $permissionModel->findAll();
            return array_column($allPermissions, 'slug');
        }

        // Retrieve user permissions for non-superadmin users
        $rolePermissionModel = new RolePermissionModel();
        $permissions = $rolePermissionModel
            ->select('permissions.slug')
            ->join('permissions', 'permissions.id = role_permissions.permission_id')
            ->where('role_permissions.role_id', $user['role_id'])
            ->findAll();

        return array_column($permissions ?? [], 'slug');
    }

    protected function render($view, $data = [])
    {
        $data = array_merge($this->viewData, $data);
        return view($view, $data);
    }
}
