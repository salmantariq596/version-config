<?php

namespace App\Filters;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\Response;
use App\Models\RolePermissionModel;
use Config\Services;
use Exception;

class PermissionFilter implements FilterInterface
{
    private $session;
    private const SUPER_ADMIN_ROLE_ID = 3;

    public function __construct()
    {
        $this->session = Services::session();
    }

    public function before(RequestInterface $request, $arguments = null)
    {
        try {
            // Convert arguments array to string for logging
            $argumentsString = is_array($arguments) ? implode(', ', $arguments) : (string)$arguments;
            log_message('debug', 'Permission check started for arguments: ' . $argumentsString);

            if (!$this->verifySessionIntegrity()) {
                log_message('error', 'Session integrity check failed');
                $this->cleanupSession();
                return $this->handleUnauthorizedAccess($request, 'Invalid session detected.');
            }

            $user = $this->session->get('user');

            // Safe logging of user data
            if ($user) {
                log_message('debug', 'User data: ' . json_encode([
                    'user_id' => $user['id'] ?? 'not_set',
                    'role_id' => $user['role_id'] ?? 'not_set'
                ]));
            } else {
                log_message('debug', 'No user data in session');
            }

            if (!$user) {
                return redirect()->to('/user-login');
            }

            if (empty($arguments)) {
                return;
            }

            if ($this->isSuperAdmin($user)) {
                log_message('debug', 'Super admin access granted');
                return;
            }

            $userPermissions = $this->getUserPermissions($user['role_id']);

            // Safe logging of permissions
            log_message('debug', 'User permissions: ' . json_encode($userPermissions));

            if ($this->hasRequiredPermission($arguments, $userPermissions)) {
                return;
            }

            return $this->handleUnauthorizedAccess($request);
        } catch (Exception $e) {
            log_message('critical', 'Permission filter error: ' . $e->getMessage());
            log_message('critical', 'Stack trace: ' . $e->getTraceAsString());

            $this->cleanupSession();
            return $this->handleError($request);
        }
    }

    private function verifySessionIntegrity(): bool
    {
        if (!$this->session->has('user')) {
            return false;
        }

        // Add session start time check if not exists
        if (!$this->session->has('session_start_time')) {
            $this->session->set('session_start_time', time());
        }

        // Check session age (24 hours)
        $sessionStartTime = $this->session->get('session_start_time');
        return (time() - $sessionStartTime) <= 86400;
    }

    private function cleanupSession(): void
    {
        try {
            $sessionId = session_id();
            $this->session->remove(['user', 'session_start_time']);
            $this->session->destroy();

            log_message('info', 'Session cleaned up successfully: ' . $sessionId);
        } catch (Exception $e) {
            log_message('error', 'Session cleanup failed: ' . $e->getMessage());
        }
    }

    private function isSuperAdmin(array $user): bool
    {
        return isset($user['username']) && $user['username'] == "admin";
    }

    private function getUserPermissions(int $roleId): array
    {
        try {
            $rolePermissionModel = new RolePermissionModel();
            $permissions = $rolePermissionModel
                ->select('permissions.slug')
                ->join('permissions', 'permissions.id = role_permissions.permission_id')
                ->where('role_permissions.role_id', $roleId)
                ->findAll();

            return array_column($permissions ?? [], 'slug');
        } catch (Exception $e) {
            log_message('error', 'Permission retrieval error: ' . $e->getMessage());
            return [];
        }
    }

    private function hasRequiredPermission(array $requiredPermissions, array $userPermissions): bool
    {
        if (empty($userPermissions)) {
            log_message('warning', 'User has no permissions. Setting flash message and redirecting.');

            session()->destroy();

            redirect()
                ->back();

            return false; // Ensure the function returns a boolean as declared
        }

        // Check for required permissions
        foreach ($requiredPermissions as $required) {
            if (in_array($required, $userPermissions)) {
                return true;
            }
        }

        // Log failed permission check
        log_message('debug', 'Permission check failed. Required: ' . json_encode($requiredPermissions) .
            ', User has: ' . json_encode($userPermissions));
        return false;
    }

    private function handleUnauthorizedAccess(RequestInterface $request, string $message = 'You do not have permission to perform this action.'): mixed
    {
        if ($request->isAJAX()) {
            return Services::response()
                ->setJSON([
                    'success' => false,
                    'message' => $message
                ])
                ->setStatusCode(403);
        }

        return redirect()
            ->to('/user-login')
            ->with('error', $message);
    }

    private function handleError(RequestInterface $request): mixed
    {
        $errorMessage = 'An unexpected error occurred. Please try again later.';

        if ($request->isAJAX()) {
            return Services::response()
                ->setJSON([
                    'success' => false,
                    'message' => $errorMessage
                ])
                ->setStatusCode(500);
        }

        return redirect()
            ->to('/user-login')
            ->with('error', $errorMessage);
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // No after-filter logic needed
    }
}
