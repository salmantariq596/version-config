<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;

class AuthMiddleware implements FilterInterface
{
    public function before($request, $arguments = null)
    {
        if (!session()->get('user')) {
            return redirect()->to('/user-login');
        }
    }

    public function after($request, $response, $arguments = null)
    {
        // Do nothing
    }
}
