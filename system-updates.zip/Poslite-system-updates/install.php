<?php
session_start();

// Check if installation is already completed
if (file_exists('app/config/app-config.php')) {
    die('Installation is already completed.');
}

// Include the router
require_once 'install/routes.php';
 