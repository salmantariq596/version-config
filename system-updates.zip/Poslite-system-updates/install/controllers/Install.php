<?php
class Install
{
    private $schemaPath;
    private $viewsPath;
    private $errors = [];
    private $pdo;
    private $steps = [
        'welcome' => ['number' => 1, 'title' => 'Welcome'],
        'requirements' => ['number' => 2, 'title' => 'System Requirements'],
        'app_configuration' => ['number' => 3, 'title' => 'Application Configuration'],
        'database' => ['number' => 4, 'title' => 'Database Setup'],
        'config' => ['number' => 5, 'title' => 'System Configuration'],
        'finish' => ['number' => 6, 'title' => 'Installation Complete']
    ];

    public function __construct()
    {
        try {
            $this->schemaPath = __DIR__ . '/../sql/schema.sql';
            $this->viewsPath = __DIR__ . '/../views/';

            if (session_status() === PHP_SESSION_NONE) {
                session_start();
            }
        } catch (Exception $e) {
            $this->addError('Initialization Error', $e->getMessage());
        }
    }

    private function addError($title, $message)
    {
        $this->errors[] = [
            'title' => $title,
            'message' => $message
        ];
    }

    public function hasErrors()
    {
        return !empty($this->errors);
    }

    public function getErrors()
    {
        return $this->errors;
    }

    public function displayErrors()
    {
        if ($this->hasErrors()) {
            echo '<div class="alert alert-danger">';
            foreach ($this->errors as $error) {
                echo '<div class="error-item">';
                echo '<strong>' . htmlspecialchars($error['title']) . ':</strong> ';
                echo htmlspecialchars($error['message']);
                echo '</div>';
            }
            echo '</div>';
        }
    }

    public function welcome()
    {
        try {
            if (!file_exists($this->viewsPath . 'welcome.php')) {
                throw new Exception('Welcome view file not found. Please ensure all installation files are present.');
            }
            include $this->viewsPath . 'welcome.php';
        } catch (Exception $e) {
            $this->addError('Welcome Page Error', $e->getMessage());
        }
        $this->displayErrors();
    }

    public function checkRequirements()
    {
        try {
            if (!function_exists('version_compare')) {
                throw new Exception('PHP version comparison function is not available. Please check your PHP installation.');
            }

            $requirements = [
                'PHP Version (8.1 or higher)' => version_compare(PHP_VERSION, '8.1', '>='),
                'PDO Extension' => extension_loaded('pdo'),
                'MySQL PDO Extension' => extension_loaded('pdo_mysql'),
            ];

            // Determine if all requirements are met
            $all_requirements_met = !in_array(false, $requirements, true);

            foreach ($requirements as $requirement => $met) {
                if (!$met) {
                    $this->addError('System Requirement', "The requirement '$requirement' is not met.");
                }
            }

            if (!file_exists($this->schemaPath)) {
                throw new Exception('Database schema file is missing. Please ensure schema.sql is present in the SQL directory.');
            }

            // Pass variables to the view
            include $this->viewsPath . 'requirements.php';
        } catch (Exception $e) {
            $this->addError('Requirements Check Error', $e->getMessage());
        }
        $this->displayErrors();
    }


    public function setupDatabase()
    {
        try {
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $required = ['db_host', 'db_name', 'db_user', 'environment'];
                foreach ($required as $field) {
                    if (empty($_POST[$field])) {
                        throw new Exception("The field '$field' is required. Please provide all necessary information.");
                    }
                }

                // Validate environment
                $environment = $_POST['environment'];
                if (!in_array($environment, ['development', 'production'])) {
                    throw new Exception("Invalid environment selected. Please choose either 'development' or 'production'.");
                }

                $_SESSION['app_config'] = [
                    'environment' => $environment,
                ];

                $host = $_POST['db_host'];
                $name = $_POST['db_name'];
                $user = $_POST['db_user'];
                $pass = $_POST['db_pass'];

                try {
                    $dsn = "mysql:host=$host";
                    $pdo = new PDO($dsn, $user, $pass);
                    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                    // Test database creation
                    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$name`");
                    $pdo->exec("USE `$name`");

                    // Store all configuration including environment
                    $_SESSION['db'] = compact('host', 'name', 'user', 'pass', 'environment');

                    // Set additional environment-specific configurations
                    $_SESSION['config']['debug'] = ($environment === 'development');
                    $_SESSION['config']['display_errors'] = ($environment === 'development');

                    header('Location: install.php?step=config');
                    exit;
                } catch (PDOException $e) {
                    throw new Exception("Database connection failed: " . $e->getMessage() .
                        ". Please verify your database credentials and ensure the MySQL server is running.");
                }
            }
        } catch (Exception $e) {
            $this->addError('Database Setup Error', $e->getMessage());
        }

        include $this->viewsPath . 'database.php';
        $this->displayErrors();
    }

    public function systemConfig()
    {
        try {
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $required = ['base_url','admin_username', 'admin_email', 'admin_pass'];
                foreach ($required as $field) {
                    if (empty($_POST[$field])) {
                        throw new Exception("The field '$field' is required. Please fill in all system configuration fields.");
                    }
                }

                if (!filter_var($_POST['admin_email'], FILTER_VALIDATE_EMAIL)) {
                    throw new Exception('Please provide a valid email address for the administrator account.');
                }

                if (strlen($_POST['admin_pass']) < 8) {
                    throw new Exception('Administrator password must be at least 8 characters long.');
                }

                // Store these in variables before using compact()
                $base_url = rtrim($_POST['base_url'], '/');
                $admin_username = $_POST['admin_username'];
                $admin_email = $_POST['admin_email'];
                $admin_pass = password_hash($_POST['admin_pass'], PASSWORD_BCRYPT);


                // Now these variables are in scope for compact()
                $_SESSION['config'] = compact('base_url', 'admin_email', 'admin_pass', 'admin_username');

                if (empty($_SESSION['db'])) {
                    throw new Exception('Database configuration is missing. Please complete the database setup first.');
                }

                $this->finalizeInstallation();
                header('Location: install.php?step=finish');
                exit;
            }
        } catch (Exception $e) {
            $this->addError('System Configuration Error', $e->getMessage());
        }

        include $this->viewsPath . 'config.php';
        $this->displayErrors();
    }

    private function finalizeInstallation()
    {
        try {
            if (!isset($_SESSION['db']) || !isset($_SESSION['config'])) {
                throw new Exception('Configuration data is incomplete. Please complete all previous installation steps.');
            }

            $config = $_SESSION['db'];

            // Establish database connection
            $this->pdo = new PDO(
                "mysql:host={$config['host']};dbname={$config['name']}",
                $config['user'],
                $config['pass'],
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8mb4'
                ]
            );

            // Read and execute schema
            $schemaContent = file_get_contents($this->schemaPath);
            if (!$schemaContent) {
                throw new Exception('Unable to read the schema file.');
            }

            // Parse SQL file into individual statements
            $statements = $this->parseSQLFile($schemaContent);
            if (empty($statements)) {
                throw new Exception('No valid SQL statements found in the schema file.');
            }

            // Execute each SQL statement
            $this->executeSchemaStatements($statements);

            // Insert admin user into the users table
            $adminEmail = $_SESSION['config']['admin_email'];
            $adminPass = $_SESSION['config']['admin_pass'];
            $adminUsername = $_SESSION['config']['admin_username'];
            $stmt = $this->pdo->prepare("INSERT INTO users (username,email, password, role_id) VALUES (?, ?, ?, 1)");
            $stmt->execute([$adminUsername, $adminEmail, $adminPass]);
        } catch (Exception $e) {
            $this->addError('Installation Error', $e->getMessage());
            throw $e;
        }
    }

    private function parseSQLFile($content)
    {
        // Remove comments
        $content = preg_replace([
            '/--[^\n]*/',         // Single line comments
            '/\/\*[\s\S]*?\*\//'  // Multi-line comments
        ], '', $content);

        // Normalize line endings and whitespace
        $content = str_replace(["\r\n", "\r"], "\n", $content);
        $content = trim($content);

        if (empty($content)) {
            return [];
        }

        // Split into statements
        $statements = [];
        $buffer = '';
        $lines = explode("\n", $content);

        foreach ($lines as $line) {
            $line = trim($line);
            if (empty($line)) {
                continue;
            }

            $buffer .= ' ' . $line;

            if (substr($line, -1) === ';') {
                $statement = trim($buffer);
                if (!empty($statement)) {
                    // Remove the trailing semicolon
                    $statement = rtrim($statement, ';');
                    if (!empty($statement)) {
                        $statements[] = $statement;
                    }
                }
                $buffer = '';
            }
        }

        // Handle any remaining statement without semicolon
        $buffer = trim($buffer);
        if (!empty($buffer)) {
            $statements[] = $buffer;
        }

        return array_filter($statements, function ($stmt) {
            return !empty(trim($stmt));
        });
    }

    private function createInstallLockFile()
    {
        $lockFileContent = "Installation completed on " . date('Y-m-d H:i:s');
        return $lockFileContent;
    }

    public function finish()
    {
        try {
            // First ensure database connection is established
            if (!isset($_SESSION['db'])) {
                throw new Exception('Database configuration is missing. Please complete the database setup first.');
            }

            // Establish database connection
            $config = $_SESSION['db'];
            $this->pdo = new PDO(
                "mysql:host={$config['host']};dbname={$config['name']}",
                $config['user'],
                $config['pass'],
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8mb4'
                ]
            );

            // Now proceed with version tracking
            $version = $this->initializeVersionTracking();

            // Generate .env file
            $envContent = $this->generateEnvFile();
            $envFile = __DIR__ . '/../../.env';
            if (!file_put_contents($envFile, $envContent)) {
                throw new Exception('Failed to write .env file. Check folder permissions.');
            }

            // Create install.lock file
            $lockFile = __DIR__ . '/../../install.lock';
            $lockContent = "Installation completed at " . date('Y-m-d H:i:s');
            if (!file_put_contents($lockFile, $lockContent)) {
                throw new Exception('Failed to create install.lock. Check permissions.');
            }

            // Handle installer file
            $installerFile = __DIR__ . '/../../install.php';
            if (file_exists($installerFile)) {
                rename($installerFile, __DIR__ . '/../../install.disabled');
            }

            // Show finish page
            include $this->viewsPath . 'finish.php';
            session_write_close();
        } catch (Exception $e) {
            $this->addError('Finish Page Error', $e->getMessage());
            $this->displayErrors();
        }
    }

    private function initializeVersionTracking()
    {
        try {
            $version = '1.0.0';

            // Check if app_versions table exists
            $tableExists = $this->pdo->query("SHOW TABLES LIKE 'app_versions'");

            if ($tableExists->rowCount() > 0) {
                // Check if table is empty
                $checkEmpty = $this->pdo->query("SELECT COUNT(*) as count FROM app_versions");
                $isEmpty = $checkEmpty->fetch(PDO::FETCH_ASSOC)['count'] == 0;

                if ($isEmpty) {
                    $stmt = $this->pdo->prepare("
                    INSERT INTO app_versions (
                        version,
                        last_checked,
                        created_at
                    ) VALUES (?, NOW(), NOW())
                ");

                    $stmt->execute([$version]);
                }
            } else {
                // Table should be created via migrations - throw error
                throw new Exception('app_versions table not found. Run database migrations first.');
            }

            return $version;
        } catch (PDOException $e) {
            throw new Exception('Failed to initialize version tracking: ' . $e->getMessage());
        }
    }

    private function generateAppKey($length = 32)
    {
        return bin2hex(random_bytes($length));
    }


    private function generateEnvFile()
    {
        try {
            // Validate required session data
            if (!isset($_SESSION['db'])) {
                throw new Exception('Database configuration is missing. Please complete the database setup first.');
            }

            if (!isset($_SESSION['config'])) {
                throw new Exception('System configuration is missing. Please complete the system setup first.');
            }

            // Set default environment and app key if app_config is not set
            $environment = isset($_SESSION['app_config']['environment'])
                ? $_SESSION['app_config']['environment']
                : 'production';

            $appKey = isset($_SESSION['app_config']['app_key'])
                ? $_SESSION['app_config']['app_key']
                : $this->generateAppKey();

            $dbConfig = $_SESSION['db'];
            $baseURL = $_SESSION['config']['base_url'];

            // Generate comprehensive environment configuration
            $envContent = [
                "# Environment Configuration",
                "# Generated on " . date('Y-m-d H:i:s'),
                "",
                "CI_ENVIRONMENT = {$environment}",
                "",
                "# Application Settings",
                "app.baseURL = '{$baseURL}'",
                "app.appKey = '{$appKey}'",
                "app.indexPage = ''",
                "app.defaultLocale = 'en'",
                "app.negotiateLocale = false",
                "app.supportedLocales = ['en']",
                "",
                "# Database Configuration",
                "database.default.hostname = '{$dbConfig['host']}'",
                "database.default.database = '{$dbConfig['name']}'",
                "database.default.username = '{$dbConfig['user']}'",
                "database.default.password = '{$dbConfig['pass']}'",
                "database.default.DBDriver = 'MySQLi'",
                "database.default.DBPrefix = ''",
                "database.default.port = 3306",
                "",
                "# Security Configuration",
                "security.tokenName = 'csrf_token_name'",
                "security.headerName = 'X-CSRF-TOKEN'",
                "security.cookieName = 'csrf_cookie_name'",
                "security.expires = 7200",
                "security.regenerate = true",
                "security.redirect = true",
                "",
                "# Cache Configuration",
                "cache.handler = 'file'",
                "cache.prefix = 'pos_'",
                "app.config_file_path = 'https://raw.githubusercontent.com/salmantariq596/version-config/refs/heads/main/version_config.json'",
            ];

            return implode("\n", $envContent);
        } catch (Exception $e) {
            $this->addError('Environment Configuration Error', $e->getMessage());
            return false;
        }
    }

    private function executeSchemaStatements(array $statements)
    {
        $totalStatements = count($statements);
        foreach ($statements as $index => $statement) {
            try {
                if (empty(trim($statement))) {
                    continue;
                }
                $this->pdo->exec($statement);

                // Calculate and store progress
                $progress = ($index + 1) / $totalStatements * 100;
                $_SESSION['installation_progress'] = $progress;

                // Simulate some delay to show progress
                usleep(100000); // 0.1 second delay
            } catch (PDOException $e) {
                throw new Exception(sprintf(
                    'SQL execution failed on statement %d: %s. Statement: %s',
                    $index + 1,
                    $e->getMessage(),
                    $statement
                ));
            }
        }
    }

    public function getCurrentStep()
    {
        $step = $_GET['step'] ?? 'welcome';
        return $this->steps[$step] ?? $this->steps['welcome'];
    }

    public function getSteps()
    {
        return $this->steps;
    }
}
