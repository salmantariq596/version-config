<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Installation Wizard - Welcome</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <div class="wizard-container">
        <div class="step-card">
            <div class="step-indicator">Step 1 of 4</div>
            <div class="app-name">POS LITE Installation Wizard</div>
            <div class="progress-bar">
                <div class="progress-fill"></div>
            </div>
            <h1>Welcome to POS LITE</h1>
            <p>Thank you for choosing POS LITE. This wizard will guide you through the installation process. We'll help you set up your application quickly and efficiently.</p>
            <a href="install.php?step=requirements" class="btn">Begin Installation →</a>
        </div>
    </div>
</body>
</html>