<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Installation Wizard - Database Configuration</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
</head>

<body>
    <div class="wizard-container">
        <div class="step-card">
            <div class="step-indicator">Step 3 of 4</div>
            <div class="app-name">POS LITE Installation Wizard</div>
            <div class="progress-bar">
                <div class="progress-fill" style="width: 75%"></div>
            </div>

            <h1>Database Configuration</h1>

            <?php if (isset($error)): ?>
                <div class="error-message"><?php echo $error; ?></div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-group">
                    <label>Project Environment:</label>
                    <select name="environment" required>
                        <option value="development">Development</option>
                        <option value="production">Production</option>
                    </select>
                    <p class="info-text">Choose 'Development' for testing and debugging, 'Production' for live deployment.</p>
                </div>

                <div class="form-group">
                    <label>Database Host:</label>
                    <input type="text" name="db_host" placeholder="e.g., localhost" required>
                </div>

                <div class="form-group">
                    <label>Database Name:</label>
                    <input type="text" name="db_name" placeholder="Enter database name" required>
                </div>

                <div class="form-group">
                    <label>Username:</label>
                    <input type="text" name="db_user" placeholder="Database username" required>
                </div>

                <div class="form-group">
                    <label>Password:</label>
                    <div class="input-group password-toggle-container">
                        <input type="password" name="db_pass" placeholder="Database password">
                        <span class="password-toggle" onclick="togglePassword()">
                            <i class="bi bi-eye-slash" id="toggleIcon"></i>
                        </span>
                    </div>
                </div>

                <div class="actions">
                    <a href="install.php?step=requirements" class="btn btn-secondary">← Previous</a>
                    <button type="submit" class="btn">Continue →</button>
                </div>
            </form>
        </div>
    </div>
</body>

</html>