<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Installation Wizard - Installation Complete</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <style>
        .version-info {
            background-color: #f0f9ff;
            border: 1px solid #bae6fd;
            border-radius: 8px;
            padding: 1.5rem;
            margin: 2rem 0;
            text-align: left;
        }
        
        .version-badge {
            display: inline-block;
            background-color: #0ea5e9;
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.875rem;
            font-weight: 500;
            margin-bottom: 0.5rem;
        }

        .success-icon {
            font-size: 4rem;
            color: #059669;
            margin-bottom: 1.5rem;
        }

        .installation-details {
            text-align: left;
            margin: 2rem 0;
            padding: 1rem;
            background: #f8fafc;
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <div class="wizard-container">
        <div class="step-card">
            <div class="success-icon">✓</div>
            <h1>Installation Completed Successfully</h1>
            
            <div class="version-info">
                <span class="version-badge">Version <?php echo htmlspecialchars($version); ?></span>
                <p>POS LITE has been successfully installed on your system. The application is now ready to use.</p>
            </div>

            <div class="installation-details">
                <h3>Installation Details:</h3>
                <p>• Installation Date: <?php echo date('F j, Y, g:i a'); ?></p>
                <p>• Environment: <?php echo htmlspecialchars($_SESSION['db']['environment'] ?? 'Production'); ?></p>
                <p>• Base URL: <?php echo htmlspecialchars($_SESSION['config']['base_url']); ?></p>
            </div>

            <p>You can now log in using your administrator credentials.</p>
            <div class="actions">
                <a href="user-login" class="btn">Continue →</a>
            </div>
        </div>
    </div>
</body>
</html>