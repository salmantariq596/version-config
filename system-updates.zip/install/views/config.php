<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Installation Wizard - System Configuration</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        .form-group {
            margin-bottom: 1.5rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: var(--text-secondary);
        }

        input {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            font-size: 1rem;
            transition: all 0.2s ease;
        }

        input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        .input-hint {
            font-size: 0.875rem;
            color: var(--text-secondary);
            margin-top: 0.5rem;
        }
    </style>
</head>

<body>
    <div class="wizard-container">
        <div class="step-card">
            <div class="step-indicator">Step 4 of 4</div>
            <div class="app-name">POS LITE Installation Wizard</div>
            <div class="progress-bar">
                <div class="progress-fill" style="width: 100%"></div>
            </div>

            <h1>System Configuration</h1>

            <form method="POST">
                <div class="form-group">
                    <label>Base URL:</label>
                    <input type="text" name="base_url" placeholder="e.g., http://yourdomain.com" required>
                    <p class="input-hint">The full URL where your application will be accessed</p>
                </div>

                <div class="form-group">
                    <label>Admin Username:</label>
                    <input type="text" name="admin_username" placeholder="Choose an admin username" required>
                    <p class="input-hint">Username for the administrator account (minimum 4 characters)</p>
                </div>

                <div class="form-group">
                    <label>Admin Email:</label>
                    <input type="email" name="admin_email" placeholder="admin@example.com" required>
                    <p class="input-hint">Your email address for administrative notifications</p>
                </div>

                <div class="form-group">
                    <label>Admin Password:</label>
                    <div class="input-group password-toggle-container">
                        <input type="password" name="admin_pass" placeholder="Choose a strong password" required>
                        <span class="password-toggle" onclick="togglePassword()">
                            <i class="bi bi-eye-slash" id="toggleIcon"></i>
                        </span>
                    </div>
                    <p class="input-hint">Minimum 8 characters, should include numbers and special characters</p>
                </div>

                <div class="actions">
                    <a href="install.php?step=database" class="btn btn-secondary">← Previous</a>
                    <button type="submit" class="btn">Complete Installation →</button>
                </div>
            </form>
        </div>
    </div>
</body>
<script>
    function togglePassword() {
        const passwordField = document.getElementById('password');
        const toggleIcon = document.getElementById('toggleIcon');

        if (passwordField.type === 'password') {
            passwordField.type = 'text';
            toggleIcon.classList.remove('bi-eye-slash');
            toggleIcon.classList.add('bi-eye');
        } else {
            passwordField.type = 'password';
            toggleIcon.classList.remove('bi-eye');
            toggleIcon.classList.add('bi-eye-slash');
        }
    }
</script>

</html>