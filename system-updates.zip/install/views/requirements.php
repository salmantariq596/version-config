<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Installation Wizard - System Requirements</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <div class="wizard-container">
        <div class="step-card">
            <div class="step-indicator">Step 2 of 4</div>
            <div class="app-name">POS LITE Installation Wizard</div>
            <div class="progress-bar">
                <div class="progress-fill" style="width: 50%"></div>
            </div>
            
            <h1>System Requirements Check</h1>
            
            <ul class="requirements-list">
                <?php foreach ($requirements as $requirement => $status): ?>
                    <li class="requirement-item">
                        <span class="requirement-label">
                            <?php if ($status): ?>
                                <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                    <path d="M16.7 5.3c.4.4.4 1 0 1.4l-8 8c-.4.4-1 .4-1.4 0l-4-4c-.4-.4-.4-1 0-1.4.4-.4 1-.4 1.4 0L8 12.6l7.3-7.3c.4-.4 1-.4 1.4 0z" fill="#166534"/>
                                </svg>
                            <?php else: ?>
                                <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                    <path d="M14.7 5.3c.4-.4 1-.4 1.4 0 .4.4.4 1 0 1.4L11.4 10l4.7 4.7c.4.4.4 1 0 1.4-.4.4-1 .4-1.4 0L10 11.4l-4.7 4.7c-.4.4-1 .4-1.4 0-.4-.4-.4-1 0-1.4L8.6 10 3.9 5.3c-.4-.4-.4-1 0-1.4.4-.4 1-.4 1.4 0L10 8.6l4.7-4.7z" fill="#991b1b"/>
                                </svg>
                            <?php endif; ?>
                            <?php echo $requirement; ?>
                        </span>
                        <span class="status <?php echo $status ? 'status-ok' : 'status-failed'; ?>">
                            <?php echo $status ? 'OK' : 'Failed'; ?>
                        </span>
                    </li>
                <?php endforeach; ?>
            </ul>

            <div class="actions">
                <a href="install.php?step=welcome" class="btn btn-secondary">← Previous</a>
                <?php if ($all_requirements_met): ?>
                    <a href="install.php?step=database" class="btn">Continue →</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>