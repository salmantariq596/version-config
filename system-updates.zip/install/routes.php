<?php
require_once 'controllers/Install.php';

$install = new Install();

$step = $_GET['step'] ?? 'welcome';

switch ($step) {
    case 'welcome':
        $install->welcome();
        break;
    case 'requirements':
        $install->checkRequirements();
        break;
    case 'database':
        $install->setupDatabase();
        break;
    case 'config':
        $install->systemConfig();
        break;
    case 'finish':
        $install->finish();
        break;
    default:
        $install->welcome();
        break;
}
