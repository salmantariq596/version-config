<?php

namespace App\Libraries;

use App\Models\MenuSectionModel;
use App\Models\MenuItemModel;
use App\Models\PermissionModel;

class MenuManager
{
    private static $instance = null;
    private $menuSectionModel;
    private $menuItemModel;
    private $permissionModel;
    private $registeredMenus = [];

    private function __construct()
    {
        $this->menuSectionModel = new MenuSectionModel();
        $this->menuItemModel = new MenuItemModel();
        $this->permissionModel = new PermissionModel();
    }

    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function registerSection($name, $icon, $position = 0, $options = [])
    {
        // Generate a slug for the section
        $slug = isset($options['slug']) ? $options['slug'] : url_title('manage-'.$name, true);

        $sectionData = [
            'name' => $name,
            'icon' => $icon,
            'order_position' => $position,
            'slug' => $slug,
            'active' => $options['active'] ?? true
        ];

        // Start a database transaction
        $this->menuSectionModel->db->transStart();

        try {
            // Check if section already exists
            $existingSection = $this->menuSectionModel
                ->where('name', $name)
                ->first();

            if (!$existingSection) {
                $sectionId = $this->menuSectionModel->insert($sectionData);
            } else {
                $sectionId = $existingSection['id'];
                $this->menuSectionModel->update($sectionId, $sectionData);
            }

            // Create or update corresponding permission
            $permissionSlug = url_title('manage-'.$name, true);
            $permissionData = [
                'name' => "Access {$name} Section",
                'description' => "Permission to access the {$name} section of the menu",
                'slug' => $permissionSlug
            ];

            $existingPermission = $this->permissionModel
                ->where('slug', $permissionSlug)
                ->first();

            if (!$existingPermission) {
                // Disable validation temporarily as we're handling uniqueness ourselves
                $this->permissionModel->skipValidation(true);
                $this->permissionModel->insert($permissionData);
                $this->permissionModel->skipValidation(false);
            } else {
                $this->permissionModel->skipValidation(true);
                $this->permissionModel->update($existingPermission['id'], $permissionData);
                $this->permissionModel->skipValidation(false);
            }

            $this->menuSectionModel->db->transCommit();
            return $sectionId;
        } catch (\Exception $e) {
            $this->menuSectionModel->db->transRollback();
            log_message('error', 'Failed to register menu section: ' . $e->getMessage());
            throw $e;
        }
    }

    public function addMenuItem($sectionName, $itemData)
    {
        // Get section ID
        $section = $this->menuSectionModel
            ->where('name', $sectionName)
            ->first();

        if (!$section) {
            throw new \Exception("Menu section '{$sectionName}' not found");
        }

        $menuItem = [
            'section_id' => $section['id'],
            'name' => $itemData['name'],
            'icon' => $itemData['icon'] ?? 'circle',
            'url' => $itemData['url'],
            'icon_color' => $itemData['icon_color'] ?? '#007bff',
            'order_position' => $itemData['position'] ?? 0,
            'active' => $itemData['active'] ?? true
        ];

        // Check if menu item already exists
        $existingItem = $this->menuItemModel
            ->where('section_id', $section['id'])
            ->where('name', $itemData['name'])
            ->first();

        if (!$existingItem) {
            return $this->menuItemModel->insert($menuItem);
        } else {
            return $this->menuItemModel->update($existingItem['id'], $menuItem);
        }
    }

    public function registerMenu($items)
    {
        foreach ($items as $section => $menuItems) {
            if (!isset($this->registeredMenus[$section])) {
                $this->registeredMenus[$section] = [];
            }

            foreach ($menuItems as $item) {
                $this->registeredMenus[$section][] = $item;
            }
        }
    }

    public function initializeMenus()
    {
        foreach ($this->registeredMenus as $sectionName => $items) {
            // Parse section data
            $sectionData = $this->parseSectionName($sectionName);

            // Register section with slug
            $this->registerSection(
                $sectionData['name'],
                $sectionData['icon'],
                $sectionData['position'],
                ['slug' => $sectionData['slug'] ?? null]
            );

            // Add items
            foreach ($items as $item) {
                $this->addMenuItem($sectionData['name'], $item);
            }
        }
    }

    private function parseSectionName($section)
    {
        // Updated format: "name|icon|position|slug"
        $parts = explode('|', $section);
        return [
            'name' => $parts[0],
            'icon' => $parts[1] ?? 'box',
            'position' => $parts[2] ?? 0,
            'slug' => $parts[3] ?? null
        ];
    }
}
