<?php

namespace App\Libraries;

use CodeIgniter\API\ResponseTrait;
use CodeIgniter\Database\Exceptions\DatabaseException;
use CodeIgniter\HTTP\IncomingRequest;
use CodeIgniter\HTTP\Response;
use Config\Services;
use Exception;
use Throwable;

class AdvancedErrorHandler
{
    use ResponseTrait;

    private $response;
    private $request;
    private $logger;
    private $db;
    private $session;

    // Maximum retry attempts for database operations
    private const MAX_RETRIES = 3;

    // Recoverable error types
    private const RECOVERABLE_ERRORS = [
        E_NOTICE => true,
        E_WARNING => true,
        E_DEPRECATED => true,
        E_USER_NOTICE => true,
        E_USER_WARNING => true,
        E_USER_DEPRECATED => true,
    ];

    public function __construct()
    {
        $this->response = Services::response();
        $this->request = Services::request();
        $this->logger = Services::logger();
        $this->db = \Config\Database::connect();
        $this->session = Services::session();

        // Set custom error handler
        set_error_handler([$this, 'handleError']);

        // Set shutdown function to catch fatal errors
        register_shutdown_function([$this, 'handleFatalError']);
    }

    /**
     * Main exception handling method with fallback mechanisms
     */
    public function handleException(Throwable $exception): Response
    {
        try {
            // Attempt to log the error
            $this->logError($exception);

            // Store error in database
            $this->logErrorToDatabase($exception);

            // Get error details
            $errorDetails = $this->getErrorDetails($exception);

            // Determine response type
            return $this->isApiRequest()
                ? $this->handleApiError($errorDetails)
                : $this->handleWebError($errorDetails);
        } catch (Throwable $e) {
            // Fallback error handling if primary handling fails
            return $this->handleFallbackError($e, $exception);
        }
    }

    /**
     * Handle PHP errors
     */
    public function handleError($severity, $message, $file, $line): bool
    {
        if (!(error_reporting() & $severity)) {
            return false;
        }

        // Convert recoverable errors to exceptions
        if (isset(self::RECOVERABLE_ERRORS[$severity])) {
            throw new \ErrorException($message, 0, $severity, $file, $line);
        }

        return true;
    }

    /**
     * Handle fatal errors
     */
    public function handleFatalError(): void
    {
        $error = error_get_last();

        if ($error !== null && in_array($error['type'], [E_ERROR, E_CORE_ERROR, E_COMPILE_ERROR, E_PARSE])) {
            $exception = new \ErrorException(
                $error['message'],
                0,
                $error['type'],
                $error['file'],
                $error['line']
            );

            $this->handleException($exception)->send();
        }
    }

    /**
     * Enhanced database logging with retry mechanism and transaction
     */
    private function logErrorToDatabase(Throwable $exception): void
    {
        $retries = 0;
        $logged = false;

        while (!$logged && $retries < self::MAX_RETRIES) {
            try {
                $this->db->transStart();

                $data = [
                    'error_type' => get_class($exception),
                    'error_message' => $exception->getMessage(),
                    'file_path' => $exception->getFile(),
                    'line_number' => $exception->getLine(),
                    'stack_trace' => $exception->getTraceAsString(),
                    'server_data' => json_encode($_SERVER),
                    'request_data' => json_encode([
                        'get' => $_GET,
                        'post' => $_POST,
                        'files' => $_FILES,
                        'json' => json_decode(file_get_contents('php://input'), true)
                    ]),
                    'user_id' => $this->session->get('user_id'),
                    'ip_address' => $this->request->getIPAddress(),
                    'user_agent' => $this->request->getUserAgent()->getAgentString(),
                    'created_at' => date('Y-m-d H:i:s'),
                    'severity' => $this->getSeverityLevel($exception),
                    'http_code' => $this->getStatusCode($exception),
                    'url' => current_url(),
                    'request_method' => $this->request->getMethod()
                ];

                $this->db->table('error_logs')->insert($data);
                $this->db->transComplete();

                $logged = true;
            } catch (Throwable $e) {
                $retries++;
                if ($retries >= self::MAX_RETRIES) {
                    // Log to file if database logging fails
                    $this->logger->error('Failed to log error to database after ' . self::MAX_RETRIES . ' attempts: ' . $e->getMessage());
                }
                sleep(1); // Wait before retry
            }
        }
    }

    /**
     * Fallback error handling when primary handler fails
     */
    private function handleFallbackError(Throwable $handlerException, Throwable $originalException): Response
    {
        // Log both exceptions
        $this->logger->critical('Error handler failed: ' . $handlerException->getMessage() .
            "\nOriginal error: " . $originalException->getMessage());

        // Provide basic response when everything else fails
        $statusCode = 500;
        $message = ENVIRONMENT === 'development'
            ? 'Error handler failed: ' . $handlerException->getMessage()
            : 'An unexpected error occurred. Please try again later.';

        return $this->response
            ->setStatusCode($statusCode)
            ->setBody(view('errors/fallback_error', [
                'message' => $message,
                'title' => 'Error ' . $statusCode
            ]));
    }

    /**
     * Determine severity level of exception
     */
    private function getSeverityLevel(Throwable $exception): string
    {
        return match (true) {
            $exception instanceof DatabaseException => 'critical',
            $exception instanceof \InvalidArgumentException => 'warning',
            $exception instanceof \RuntimeException => 'error',
            default => 'error'
        };
    }

    /**
     * Main error handling method
     */
    public function handleExceptionOld(Throwable $exception): Response
    {
        // Log the error
        $this->logError($exception);

        // Determine if request expects JSON
        $isApiRequest = $this->isApiRequest();

        // Get error details
        $errorDetails = $this->getErrorDetails($exception);

        // Return appropriate response format
        return $isApiRequest
            ? $this->handleApiError($errorDetails)
            : $this->handleWebError($errorDetails);
    }

    /**
     * Log error details
     */
    private function logError(Throwable $exception): void
    {
        $message = sprintf(
            "Error: %s\nFile: %s\nLine: %d\nTrace:\n%s",
            $exception->getMessage(),
            $exception->getFile(),
            $exception->getLine(),
            $exception->getTraceAsString()
        );

        // Log additional context data
        $context = [
            'url' => current_url(),
            'ip' => $this->request->getIPAddress(),
            'user_agent' => $this->request->getUserAgent(),
            'request_data' => $this->request->getPost() ?? $this->request->getJSON()
        ];

        if (method_exists($exception, 'getStatusCode')) {
            $this->logger->error($message, $context);
        } else {
            $this->logger->critical($message, $context);
        }
    }

    /**
     * Check if request expects JSON response
     */
    private function isApiRequest(): bool
    {
        return $this->request->isAJAX() ||
            strpos($this->request->getHeaderLine('Accept'), 'application/json') !== false ||
            strpos($this->request->getPath(), 'api/') === 0;
    }

    /**
     * Get standardized error details
     */
    private function getErrorDetails(Throwable $exception): array
    {
        $statusCode = $this->getStatusCode($exception);

        return [
            'status_code' => $statusCode,
            'error_type' => get_class($exception),
            'message' => $this->getUserFriendlyMessage($exception),
            'file' => $exception->getFile(),
            'line' => $exception->getLine(),
            'trace' => ENVIRONMENT === 'development' ? $exception->getTraceAsString() : null
        ];
    }

    /**
     * Handle API errors (JSON response)
     */
    private function handleApiError(array $errorDetails): Response
    {
        return $this->response
            ->setStatusCode($errorDetails['status_code'])
            ->setJSON([
                'status' => 'error',
                'message' => $errorDetails['message'],
                'details' => ENVIRONMENT === 'development' ? $errorDetails : null
            ]);
    }

    /**
     * Handle Web errors (HTML response)
     */
    private function handleWebErrorOld(array $errorDetails): Response
    {
        // Load error view
        $viewData = [
            'title' => 'Error ' . $errorDetails['status_code'],
            'message' => $errorDetails['message']
        ];

        if (ENVIRONMENT === 'development') {
            $viewData['details'] = $errorDetails;
        }

        return $this->response
            ->setStatusCode($errorDetails['status_code'])
            ->setBody(view('errors/custom_error', $viewData));
    }

    /**
     * Get appropriate HTTP status code
     */
    private function getStatusCode(Throwable $exception): int
    {
        if (method_exists($exception, 'getStatusCode')) {
            return $exception->getStatusCode();
        }

        return match (true) {
            $exception instanceof DatabaseException => 503,
            $exception instanceof \InvalidArgumentException => 400,
            $exception instanceof \RuntimeException => 500,
            default => 500
        };
    }

    /**
     * Get user-friendly error message
     */
    private function getUserFriendlyMessage(Throwable $exception): string
    {
        if (ENVIRONMENT === 'production') {
            return match (true) {
                $exception instanceof DatabaseException => 'A database error occurred.',
                $exception instanceof \InvalidArgumentException => 'Invalid input provided.',
                default => 'An unexpected error occurred. Please try again later.'
            };
        }

        return $exception->getMessage();
    }

    private function handleWebError(array $errorDetails): Response
    {
        return $this->response
            ->setStatusCode($errorDetails['status_code'])
            ->setBody(\App\Helpers\ErrorViewHelper::getErrorTemplate(
                $errorDetails,
                ENVIRONMENT === 'development'
            ));
    }
}
