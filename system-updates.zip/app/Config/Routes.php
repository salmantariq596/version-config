<?php

namespace Config;

use CodeIgniter\Router\RouteCollection;
use CodeIgniter\Database\Exceptions\DatabaseException;

/**
 * @var RouteCollection $routes
 */

// Authentication Routes (No Auth Required)
$routes->get('/', 'AuthController::login');
$routes->get('/user-login', 'AuthController::login');
$routes->post('/user-login', 'AuthController::authenticate');

// Protected Routes
$routes->group('', ['namespace' => 'App\Controllers', 'filter' => 'auth'], function (RouteCollection $routes) {

    // Dashboard & Core System Routes
    $routes->group('', ['filter' => 'permissions:manage-Dashboard'], function ($routes) {
        $routes->get('/dashboard', 'Admin\AdminDashboard::index');
        $routes->get('/dashboard-new', 'Admin\AdminDashboard::welcome_message');
    });

    //datatable route
    $routes->get('datatable/(:segment)', 'DatatableController::listAllUsers/$1');


    // Module Management Routes
    $routes->group('module-management', ['filter' => 'permissions:manage-Module1Setting'], function ($routes) {
        $routes->get('', 'ModuleManagementController::index');
        $routes->post('upload', 'ModuleManagementController::uploadModule');
        $routes->get('toggle-status/(:num)', 'ModuleManagementController::toggleStatus/$1');
    });

    // User Management Routes
    $routes->group('', ['filter' => 'permissions:manage-User1Management'], function ($routes) {
        $routes->get('/user-register', 'AuthController::register');
        $routes->post('/user-register', 'AuthController::store');
        $routes->get('/fetch-all-users', 'AuthController::fetchUsers');
        $routes->get('/list-all-users', 'AuthController::listUsers');
    });

    // User Profile Routes (Personal Access)
    $routes->group('profile', function ($routes) {
        $routes->get('', 'AuthController::profile');
        $routes->get('edit', 'AuthController::editProfile');
        $routes->post('edit', 'AuthController::editProfile');
        $routes->post('change-password', 'AuthController::changePassword');
    });

    // Roles and Permissions Management
    $routes->group('', ['namespace' => 'App\Controllers\Admin', 'filter' => 'permissions:manage-User1Management'], function ($routes) {
        $routes->get('/roles-permissions', 'RolesPermissionsController::index');
        $routes->post('/roles/store', 'RolesPermissionsController::storeRole');
        $routes->post('/permissions/store', 'RolesPermissionsController::storePermission');
        $routes->post('/roles/assignUserRole', 'RolesPermissionsController::assignUserRole');
        $routes->post('/roles/permissions', 'RolesPermissionsController::assignRolePermissions');
        $routes->get('/roles/delete/(:num)', 'RolesPermissionsController::deleteRole/$1');
        $routes->get('/permissions/delete/(:num)', 'RolesPermissionsController::deletePermission/$1');
    });

    // Product Management
    $routes->group('', ['namespace' => 'App\Controllers\Admin', 'filter' => 'permissions:manage-Products'], function ($routes) {
        $routes->get('product', 'ProductController::index');
        $routes->get('product/add', 'ProductController::add');
        $routes->post('product/store', 'ProductController::store');
        $routes->get('product/edit/(:num)', 'ProductController::edit/$1');
        $routes->post('product/update/(:num)', 'ProductController::update/$1');
        $routes->get('product/delete/(:num)', 'ProductController::delete/$1');
        $routes->get('/productcontroller/fetchCategories', 'ProductController::fetchCategories');  // Fetch categories
        $routes->get('/productcontroller/fetchProductsByCategory/(:num)', 'ProductController::fetchProductsByCategory/$1');  // Fetch products by category
        $routes->get('/add_categories', 'ProductController::addCategoryForm');
        $routes->post('/add_category', 'ProductController::addCategory');
        $routes->get('/all_categories', 'ProductController::allCategories');
        $routes->post('product/getUnitDetails', 'ProductController::getUnitDetails');
        $routes->post('categories/delete/(:num)', 'ProductController::deleteCategory/$1');
    });

    // Inventory Management
    $routes->group('inventory', ['namespace' => 'App\Controllers\Admin', 'filter' => 'permissions:manage-Inventory'], function ($routes) {
        $routes->get('', 'Inventory::index');
        $routes->post('adjustStock', 'Inventory::adjustStock');
        $routes->get('addAdjustment', 'Inventory::addAdjustment');
        $routes->get('editAdjustment/(:num)', 'Inventory::editAdjustment/$1');
        $routes->post('updateAdjustment/(:num)', 'Inventory::updateAdjustment/$1');
        $routes->get('deleteAdjustment/(:num)', 'Inventory::deleteAdjustment/$1');
    });

    // Purchase Management
    $routes->group('purchases', ['namespace' => 'App\Controllers\Admin', 'filter' => 'permissions:manage-Purchases'], function ($routes) {
        $routes->get('allPurchases', 'PurchasesController::allPurchases');
        $routes->get('addPurchase', 'PurchasesController::addPurchase');
        $routes->post('savePurchase', 'PurchasesController::savePurchase');
        $routes->get('editPurchase/(:num)', 'PurchasesController::editPurchase/$1');
        $routes->post('updatePurchase/(:num)', 'PurchasesController::updatePurchase/$1');
        $routes->get('deletePurchase/(:num)', 'PurchasesController::deletePurchase/$1');
    });

    // Expense Management
    $routes->group('expenses', ['namespace' => 'App\Controllers\Admin', 'filter' => 'permissions:manage-Expenses'], function ($routes) {
        $routes->get('', 'ExpenseController::index');
        $routes->get('create', 'ExpenseController::create');
        $routes->post('store', 'ExpenseController::store');
        $routes->get('edit/(:num)', 'ExpenseController::edit/$1');
        $routes->post('update/(:num)', 'ExpenseController::update/$1');
        $routes->get('delete/(:num)', 'ExpenseController::delete/$1');
    });

    // POS System
    $routes->group('pos', ['namespace' => 'App\Controllers\Admin', 'filter' => 'permissions:manage-POS'], function ($routes) {
        $routes->get('', 'POSController::index');
        $routes->post('checkout', 'POSController::checkout');
        $routes->post('makeSale', 'POSController::makeSale');
        $routes->get('view_invoice/(:num)', 'POSController::viewInvoice/$1');
        $routes->get('invoice-history', 'POSController::invoiceHistory');
        $routes->get('getSaleDetails/(:num)', 'POSController::getSaleDetails/$1');
    });

    // Vendor Management
    $routes->group('newvendor', ['namespace' => 'App\Controllers\Admin', 'filter' => 'permissions:manage-Vendors'], function ($routes) {
        $routes->get('', 'Vendor::index');
        $routes->get('add', 'Vendor::add');
        $routes->post('save', 'Vendor::save');
        $routes->get('edit/(:num)', 'Vendor::edit/$1');
        $routes->post('update/(:num)', 'Vendor::update/$1');
        $routes->get('delete/(:num)', 'Vendor::delete/$1');
    });

    // Customer Management
    $routes->group('customers', ['namespace' => 'App\Controllers\Admin', 'filter' => 'permissions:manage-Customers'], function ($routes) {
        $routes->get('', 'CustomerController::index');
        $routes->get('create', 'CustomerController::create');
        $routes->post('store', 'CustomerController::store');
        $routes->get('edit/(:num)', 'CustomerController::edit/$1');
        $routes->post('update/(:num)', 'CustomerController::update/$1');
        $routes->get('delete/(:num)', 'CustomerController::delete/$1');
    });

    // Warehouse Management
    $routes->group('warehouses', ['namespace' => 'App\Controllers\Admin', 'filter' => 'permissions:manage-Warehouses'], function ($routes) {
        $routes->get('', 'WarehouseController::index');
        $routes->get('create', 'WarehouseController::create');
        $routes->post('store', 'WarehouseController::store');
        $routes->get('edit/(:num)', 'WarehouseController::edit/$1');
        $routes->post('update/(:num)', 'WarehouseController::update/$1');
        $routes->get('delete/(:num)', 'WarehouseController::delete/$1');
    });

    // Units Management
    $routes->group('units', ['namespace' => 'App\Controllers\Admin', 'filter' => 'permissions:manage-Units'], function ($routes) {
        $routes->get('', 'Units::index');
        $routes->get('create', 'Units::create');
        $routes->post('store', 'Units::store');
        $routes->get('edit/(:num)', 'Units::edit/$1');
        $routes->post('update/(:num)', 'Units::update/$1');
        $routes->get('delete/(:num)', 'Units::delete/$1');
    });

    // Brands Management
    $routes->group('brands', ['namespace' => 'App\Controllers\Admin', 'filter' => 'permissions:manage-Brands'], function ($routes) {
        $routes->get('', 'BrandController::index');
        $routes->get('create', 'BrandController::create');
        $routes->post('store', 'BrandController::store');
        $routes->get('edit/(:num)', 'BrandController::edit/$1');
        $routes->post('update/(:num)', 'BrandController::update/$1');
        $routes->get('delete/(:num)', 'BrandController::delete/$1');
    });

    // Version Management
    $routes->group('version-management', ['filter' => 'permissions:manage-Settings'], function ($routes) {
        $routes->get('', 'VersionController::index');
        $routes->get('check', 'VersionController::checkVersion');
        $routes->post('update', 'VersionController::performUpdate');
    });
});

// Logout Route (Available to authenticated users)
$routes->get('/user-logout', 'AuthController::logout', ['filter' => 'auth']);

// Dynamic Module Routes

try {
    $db = \Config\Database::connect();
    if ($db->tableExists('modules')) {
        $activeModules = $db->table('modules')->where('status', 'active')->get()->getResult();
        foreach ($activeModules as $module) {
            $routesPath = ROOTPATH . "modules/{$module->name}/routes.php";
            if (file_exists($routesPath)) {
                require_once $routesPath;
            }
        }
    }
} catch (DatabaseException $e) {
    log_message('error', 'Error loading modules: ' . $e->getMessage());
}
