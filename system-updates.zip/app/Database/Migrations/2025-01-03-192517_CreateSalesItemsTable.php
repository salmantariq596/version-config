<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateSalesItemsTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'sale_id' => [
                'type'       => 'INT',
                'unsigned'   => true,
                'null'       => false,
            ],
            'product_id' => [
                'type'       => 'INT',
                'unsigned'   => true,
                'null'       => false,
            ],
            'quantity' => [
                'type'       => 'INT',
                'unsigned'   => true,
                'null'       => false,
            ],
            'price' => [
                'type'       => 'DECIMAL',
                'constraint' => '10,2',
                'null'       => false,
            ],
            'subtotal' => [
                'type'       => 'DECIMAL',
                'constraint' => '10,2',
                'null'       => false,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id', true); // Primary key
        $this->forge->addForeignKey('sale_id', 'sales', 'id', 'CASCADE', 'CASCADE'); // Foreign key
        $this->forge->addForeignKey('product_id', 'products', 'id', 'CASCADE', 'CASCADE'); // Foreign key
        $this->forge->createTable('sales_items');
    }

    public function down()
    {
        $this->forge->dropTable('sales_items');
    }
}
