<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateDatatableConfig extends Migration
{
    public function up()
    {
        // Create the datatable_config table
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true
            ],
            'table_title' => [
                'type' => 'VARCHAR',
                'constraint' => 100,
            ],
            'table_name' => [
                'type' => 'VARCHAR',
                'constraint' => 100,
            ],
            'api_endpoint' => [
                'type' => 'VARCHAR',
                'constraint' => 255,
            ],
            'columns' => [
                'type' => 'TEXT', // JSON format
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ]
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('datatable_config');
    }

    public function down()
    {
        $this->forge->dropTable('datatable_config');
    }
}
