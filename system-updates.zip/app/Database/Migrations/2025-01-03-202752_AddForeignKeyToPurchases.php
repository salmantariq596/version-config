<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddForeignKeyToPurchases extends Migration
{
    public function up()
    {
        // Add foreign key constraint
        $this->forge->addForeignKey('vendor_id', 'vendors', 'id', 'CASCADE', 'CASCADE');
        $this->forge->processIndexes('purchases');
    }

    public function down()
    {
        // Remove foreign key constraint
        $this->db->query('ALTER TABLE purchases DROP FOREIGN KEY purchases_vendor_id_foreign');
    }
}