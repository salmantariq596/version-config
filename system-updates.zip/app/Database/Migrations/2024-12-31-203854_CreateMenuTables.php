<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateMenuTables extends Migration
{
    public function up()
    {
        // Create menu_sections table
        $this->forge->addField([
            'id' => ['type' => 'INT', 'constraint' => 5, 'unsigned' => true, 'auto_increment' => true],
            'name' => ['type' => 'VARCHAR', 'constraint' => 50],
            'icon' => ['type' => 'VARCHAR', 'constraint' => 50],
            'order_position' => ['type' => 'INT', 'constraint' => 5],
            'active' => ['type' => 'BOOLEAN', 'default' => true]
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('menu_sections');

        // Create menu_items table
        $this->forge->addField([
            'id' => ['type' => 'INT', 'constraint' => 5, 'unsigned' => true, 'auto_increment' => true],
            'section_id' => ['type' => 'INT', 'constraint' => 5, 'unsigned' => true],
            'name' => ['type' => 'VARCHAR', 'constraint' => 50],
            'icon' => ['type' => 'VARCHAR', 'constraint' => 50],
            'url' => ['type' => 'VARCHAR', 'constraint' => 255],
            'icon_color' => ['type' => 'VARCHAR', 'constraint' => 20],
            'order_position' => ['type' => 'INT', 'constraint' => 5],
            'active' => ['type' => 'BOOLEAN', 'default' => true]
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('section_id', 'menu_sections', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('menu_items');
    }

    public function down()
    {
        $this->forge->dropTable('menu_items');
        $this->forge->dropTable('menu_sections');
    }
}