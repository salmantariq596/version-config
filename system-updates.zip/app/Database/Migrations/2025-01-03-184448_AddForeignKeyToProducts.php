<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddForeignKeyToProducts extends Migration
{
    public function up()
    {
        // Add foreign key for category_id referencing categories table
        $this->forge->addForeignKey('category_id', 'categories', 'id', 'CASCADE', 'CASCADE');
    }

    public function down()
    {
        // Drop the foreign key for category_id
        $this->forge->dropForeignKey('products', 'products_category_id_foreign');
    }
}
