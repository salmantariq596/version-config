<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class UpdateMenuTables extends Migration
{
    public function up()
    {
        // Add slug column to menu_sections table
        $this->forge->addColumn('menu_sections', [
            'slug' => [
                'type' => 'VARCHAR',
                'constraint' => 255,
                'null' => false,
                'after' => 'name'
            ]
        ]);

        // Add unique index to menu_sections slug
        $this->forge->addKey('slug', false, true, 'menu_sections_slug_unique');

        // Add slug column to menu_items table
        $this->forge->addColumn('menu_items', [
            'slug' => [
                'type' => 'VARCHAR',
                'constraint' => 255,
                'null' => false,
                'after' => 'name'
            ]
        ]);

        // Add unique index to menu_items slug
        $this->forge->addKey('slug', false, true, 'menu_items_slug_unique');

        // Generate slugs for existing menu sections
        $sections = $this->db->table('menu_sections')->get()->getResultArray();
        foreach ($sections as $section) {
            $slug = url_title($section['name'], '-', true);
            $originalSlug = $slug;
            $counter = 1;
            
            // Ensure unique slug
            while ($this->db->table('menu_sections')
                ->where('slug', $slug)
                ->where('id !=', $section['id'])
                ->countAllResults() > 0) {
                $slug = $originalSlug . '-' . $counter;
                $counter++;
            }
            
            $this->db->table('menu_sections')
                ->where('id', $section['id'])
                ->update(['slug' => $slug]);
        }

        // Generate slugs for existing menu items
        $items = $this->db->table('menu_items')->get()->getResultArray();
        foreach ($items as $item) {
            $slug = url_title($item['name'], '-', true);
            $originalSlug = $slug;
            $counter = 1;
            
            // Ensure unique slug
            while ($this->db->table('menu_items')
                ->where('slug', $slug)
                ->where('id !=', $item['id'])
                ->countAllResults() > 0) {
                $slug = $originalSlug . '-' . $counter;
                $counter++;
            }
            
            $this->db->table('menu_items')
                ->where('id', $item['id'])
                ->update(['slug' => $slug]);
        }

        // Create permissions for existing menu sections
        $sections = $this->db->table('menu_sections')->get()->getResultArray();
        foreach ($sections as $section) {
            $this->db->table('permissions')->insert([
                'name' => "Access {$section['name']} Section",
                'description' => "Allows access to the {$section['name']} menu section and its features",
                'slug' => "menu.section.{$section['slug']}",
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ]);
        }

        // // Create permissions for existing menu items
        // $items = $this->db->table('menu_items')->get()->getResultArray();
        // foreach ($items as $item) {
        //     $this->db->table('permissions')->insert([
        //         'name' => "Access {$item['name']}",
        //         'description' => "Allows access to {$item['name']} menu item and its features",
        //         'slug' => "menu.item.{$item['slug']}",
        //         'created_at' => date('Y-m-d H:i:s'),
        //         'updated_at' => date('Y-m-d H:i:s')
        //     ]);
        // }
    }

    public function down()
    {
        // Remove permissions for menu items
        // $items = $this->db->table('menu_items')->get()->getResultArray();
        // foreach ($items as $item) {
        //     $this->db->table('permissions')
        //         ->where('slug', "menu.item.{$item['slug']}")
        //         ->delete();
        // }

        // Remove permissions for menu sections
        $sections = $this->db->table('menu_sections')->get()->getResultArray();
        foreach ($sections as $section) {
            $this->db->table('permissions')
                ->where('slug', "menu.section.{$section['slug']}")
                ->delete();
        }

        // Remove slug column from menu_items table
        $this->forge->dropColumn('menu_items', 'slug');

        // Remove slug column from menu_sections table
        $this->forge->dropColumn('menu_sections', 'slug');
    }
}