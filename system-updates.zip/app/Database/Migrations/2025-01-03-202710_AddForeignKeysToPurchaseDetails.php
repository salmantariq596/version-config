<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddForeignKeysToPurchaseDetails extends Migration
{
    public function up()
    {
        // Add foreign key constraints
        $this->forge->addForeignKey('purchase_id', 'purchases', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('product_id', 'products', 'id', 'CASCADE', 'CASCADE');
        $this->forge->processIndexes('purchase_details');
    }

    public function down()
    {
        // Remove foreign key constraints
        $this->db->query('ALTER TABLE purchase_details DROP FOREIGN KEY purchase_details_purchase_id_foreign');
        $this->db->query('ALTER TABLE purchase_details DROP FOREIGN KEY purchase_details_product_id_foreign');
    }
}