<?php
namespace App\Models;

use CodeIgniter\Model;

class InventoryModel extends Model
{
    protected $table = 'stock_adjustments';
    protected $allowedFields = ['product_id', 'adjustment_type', 'quantity', 'reason', 'adjusted_by', 'adjusted_at'];

    public function getAllAdjustments()
    {
        return $this->select('stock_adjustments.*, products.name AS product_name')
                    ->join('products', 'products.id = stock_adjustments.product_id', 'left')
                    ->orderBy('adjusted_at', 'DESC')
                    ->findAll();
    }

    public function adjustStock($data)
    {
        $productsModel = new \App\Models\ProductModel();  // Create an instance of ProductModel

        // Update product stock based on adjustment type (add or remove)
        $product = $productsModel->find($data['product_id']);
        if ($data['adjustment_type'] == 'add') {
            $newStock = $product['available_stock'] + $data['quantity'];
        } else {
            $newStock = $product['available_stock'] - $data['quantity'];
        }

        // Update the available stock of the product
        $productsModel->update($data['product_id'], ['available_stock' => $newStock]);

        // Insert the adjustment record into stock_adjustments table
        $this->insert([
            'product_id' => $data['product_id'],
            'adjustment_type' => $data['adjustment_type'],
            'quantity' => $data['quantity'],
            'reason' => $data['reason'],
            'adjusted_by' => 1,  // Example: Admin ID or current user ID
            'adjusted_at' => date('Y-m-d H:i:s')
        ]);
    }

    public function updateAdjustment($id, $adjustment_type, $quantity, $reason)
    {
        $adjustment = $this->find($id);
        $productsModel = new \App\Models\ProductModel();

        // Revert the previous adjustment
        $product = $productsModel->find($adjustment['product_id']);
        $stock_change = $adjustment['adjustment_type'] === 'add' ? -$adjustment['quantity'] : $adjustment['quantity'];
        $productsModel->update($adjustment['product_id'], ['available_stock' => $product['available_stock'] + $stock_change]);

        // Apply the new adjustment
        $stock_change = $adjustment_type === 'add' ? $quantity : -$quantity;
        $productsModel->update($adjustment['product_id'], ['available_stock' => $product['available_stock'] + $stock_change]);

        // Update the adjustment record
        $this->update($id, [
            'adjustment_type' => $adjustment_type,
            'quantity' => $quantity,
            'reason' => $reason,
        ]);
    }

    public function deleteAdjustment($id)
    {
        $adjustment = $this->find($id);
        $productsModel = new \App\Models\ProductModel();

        // Revert the adjustment on delete
        $product = $productsModel->find($adjustment['product_id']);
        $stock_change = $adjustment['adjustment_type'] === 'add' ? -$adjustment['quantity'] : $adjustment['quantity'];
        $productsModel->update($adjustment['product_id'], ['available_stock' => $product['available_stock'] + $stock_change]);

        // Delete the adjustment
        $this->delete($id);
    }
}


?>