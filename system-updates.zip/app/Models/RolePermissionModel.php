<?php
// app/Models/RolePermissionModel.php
namespace App\Models;

use CodeIgniter\Model;

class RolePermissionModel extends Model
{
    protected $table            = 'role_permissions';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ['role_id', 'permission_id'];

    protected $useTimestamps = false;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    protected $validationRules = [
        'role_id' => 'required|integer|is_not_unique[roles.id]',
        'permission_id' => 'required|integer|is_not_unique[permissions.id]'
    ];

    protected $validationMessages = [
        'role_id' => [
            'is_not_unique' => 'Selected role does not exist'
        ],
        'permission_id' => [
            'is_not_unique' => 'Selected permission does not exist'
        ]
    ];

    public function syncPermissions($roleId, array $permissionIds)
    {
        // Delete existing permissions for this role
        $this->where('role_id', $roleId)->delete();

        // Insert new permissions
        $data = [];
        foreach ($permissionIds as $permissionId) {
            $data[] = [
                'role_id' => $roleId,
                'permission_id' => $permissionId
            ];
        }

        if (!empty($data)) {
            return $this->insertBatch($data);
        }

        return true;
    }
}
