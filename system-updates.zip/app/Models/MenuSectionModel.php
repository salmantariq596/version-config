<?php

namespace App\Models;

use CodeIgniter\Model;

class MenuSectionModel extends Model
{
    protected $table = 'menu_sections';
    protected $primaryKey = 'id';
    protected $allowedFields = ['name', 'icon', 'order_position', 'active', 'slug'];
    protected $returnType = 'array';

    public function getActiveSections()
    {
        return $this->where('active', true)
                    ->orderBy('order_position', 'ASC')
                    ->findAll();
    }
}