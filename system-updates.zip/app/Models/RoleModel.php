<?php

namespace App\Models;

use CodeIgniter\Model;

class RoleModel extends Model
{
    protected $table            = 'roles';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ['name', 'description', 'slug'];

    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    protected $validationRules = [
        'name' => 'required|min_length[3]|max_length[255]|is_unique[roles.name,id,{id}]',
        'description' => 'required|min_length[3]'
    ];

    protected $validationMessages = [
        'name' => [
            'required' => 'Role name is required',
            'is_unique' => 'Role name must be unique'
        ]
    ];

    public function getPermissions($roleId)
    {
        return $this->db->table('role_permissions')
            ->join('permissions', 'permissions.id = role_permissions.permission_id')
            ->where('role_id', $roleId)
            ->get()
            ->getResultArray();
    }

    public function getUsers($roleId)
    {
        return $this->db->table('users')
            ->where('role_id', $roleId)
            ->get()
            ->getResultArray();
    }

    public function hasPermission($roleId, $permissionSlug)
    {
        return $this->db->table('role_permissions')
            ->join('permissions', 'permissions.id = role_permissions.permission_id')
            ->where('role_id', $roleId)
            ->where('permissions.slug', $permissionSlug)
            ->countAllResults() > 0;
    }
}