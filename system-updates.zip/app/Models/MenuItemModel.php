<?php

namespace App\Models;

use CodeIgniter\Model;

class MenuItemModel extends Model
{
    protected $table = 'menu_items';
    protected $primaryKey = 'id';
    protected $allowedFields = ['section_id', 'name', 'icon', 'url', 'icon_color', 'order_position', 'active'];
    protected $returnType = 'array';

    public function getActiveItemsBySection($sectionId)
    {
        return $this->where('section_id', $sectionId)
                    ->where('active', true)
                    ->orderBy('order_position', 'ASC')
                    ->findAll();
    }

    public function getAllMenuData()
    {
        $menuSectionModel = new MenuSectionModel();
        $sections = $menuSectionModel->getActiveSections();
        
        foreach ($sections as &$section) {
            $section['items'] = $this->getActiveItemsBySection($section['id']);
        }
        
        return $sections;
    }
}
