<?php

namespace App\Models;

use CodeIgniter\Model;

class PurchaseModel extends Model
{
    protected $table      = 'purchases';
    protected $primaryKey = 'id';
    protected $allowedFields = ['vendor_id', 'purchase_date', 'total_amount', 'pay_amount', 'pending_amount'];

    // Function to get all purchases
    public function getPurchases()
    {
        return $this->select('purchases.*, vendors.name as vendor_name, warehouses.name as warehouse_name')
                    ->join('vendors', 'vendors.id = purchases.vendor_id', 'left')
                    ->join('warehouses', 'warehouses.id = purchases.warehouse_id', 'left')
                    ->findAll();
    }

    public function getTotalPurchases()
    {
        return $this->selectSum('total_amount')->get()->getRow()->total_amount ?? 0;
    }
    
}
