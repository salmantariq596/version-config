<?php 
namespace App\Helpers;

class ErrorViewHelper
{
    public static function getErrorTemplate(array $errorDetails, bool $isDevelopment = false): string
    {
        $errorCode = $errorDetails['status_code'] ?? 500;
        $errorMessage = $errorDetails['message'] ?? 'An unexpected error occurred';
        
        return view('errors/templates/header', ['errorCode' => $errorCode]) .
               view('errors/templates/body', [
                   'errorDetails' => $errorDetails,
                   'isDevelopment' => $isDevelopment
               ]) .
               view('errors/templates/footer');
    }
}